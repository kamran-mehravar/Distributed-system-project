package com.softron.core.enums;

public enum CaseFormType {

    HIGHCOURT, ADMIN

}
