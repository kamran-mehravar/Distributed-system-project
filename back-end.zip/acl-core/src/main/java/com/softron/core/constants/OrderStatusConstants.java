package com.softron.core.constants;

import org.springframework.http.MediaType;

public interface OrderStatusConstants {

    String PENDING = "PENDING";
    String APPROVED = "APPROVED";
    String REJECTED = "REJECTED";
}
