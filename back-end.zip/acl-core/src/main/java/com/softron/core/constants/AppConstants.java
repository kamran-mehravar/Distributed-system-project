package com.softron.core.constants;

public interface AppConstants {
    
    String DATE_FORMAT = "dd/MM/yyyy";
}
