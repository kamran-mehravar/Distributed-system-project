package com.softron.core.constants;

public interface CommonTableNameConstants {

	String USER_MAPPING_TABLE = "ACL_ORG_USERS_MAPPING";

}
