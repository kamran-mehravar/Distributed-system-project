package com.softron.admin.erlang.interfaces;

public class RemoteErlangException extends Exception {
    public RemoteErlangException(String message){
        super(message);
    }
}



