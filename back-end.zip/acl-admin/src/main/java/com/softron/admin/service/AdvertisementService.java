package com.softron.admin.service;

import com.softron.admin.dto.AdvertisementDto;
import com.softron.admin.erlang.dto.AdvertisementExternalDto;
import com.softron.common.businessobjects.Response;
import org.springframework.data.domain.Pageable;

public interface AdvertisementService {
    Response create(AdvertisementExternalDto advertisementDto);

    Response update(String id, AdvertisementExternalDto advertisementDto);

    Response get(Long id);

    Response getAll(Pageable pageable, boolean isExport, String search, String status);

    Response delete(String id);
}
