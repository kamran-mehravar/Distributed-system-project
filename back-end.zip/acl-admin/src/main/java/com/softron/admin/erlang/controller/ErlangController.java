package com.softron.admin.erlang.controller;

import com.softron.admin.erlang.impl.RemoteErlangService;
import com.softron.admin.erlang.interfaces.AdvertisementDto;
import com.softron.common.utils.UrlConstants;
import com.softron.core.annotations.ApiController;
import org.springframework.web.bind.annotation.*;

@ApiController
@RequestMapping(UrlConstants.Erlang.ROOT + UrlConstants.Erlang.GET_ALL)
public class ErlangController {

    private final RemoteErlangService remoteErlangService;
    public ErlangController(RemoteErlangService remoteErlangService) {
        this.remoteErlangService = remoteErlangService;
    }

    @PostMapping("/create-advertisement")
    public String createAdvertisementTable() {
        return remoteErlangService.createAdvertisementTable();
    }

    @PostMapping("/save-advertisement")
    public String saveAdvertisement(@RequestBody AdvertisementDto advertisementDto) {
        return remoteErlangService.saveAdvertisement(advertisementDto);
    }
}
