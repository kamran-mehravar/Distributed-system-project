package com.softron.admin.erlang.interfaces;

import java.io.Serializable;
import java.util.Objects;

public class AdvertisementDto implements Serializable {
    private String title;
    private String description;
    private String region;

    public AdvertisementDto() {
    }

    public AdvertisementDto(String title, String description, String region) {
        this.title = title;
        this.description = description;
        this.region = region;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AdvertisementDto that = (AdvertisementDto) o;
        return Objects.equals(title, that.title) && Objects.equals(description, that.description) && Objects.equals(region, that.region);
    }

    @Override
    public int hashCode() {
        return Objects.hash(title, description, region);
    }

    @Override
    public String toString() {
        return "AdvertisementDto{" +
                "title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", region='" + region + '\'' +
                '}';
    }
}