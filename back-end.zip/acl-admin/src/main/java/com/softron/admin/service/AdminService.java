package com.softron.admin.service;

import com.softron.admin.dto.OrganizationDto;
import com.softron.admin.transferobjects.RoleTO;
import com.softron.common.businessobjects.Response;
import com.softron.common.exceptions.NoRecordExistsException;
import com.softron.common.exceptions.RecordAlreadyExisting;
import com.softron.common.utils.ResponseUtils;
import com.softron.schema.admin.entity.Menu;
import com.softron.schema.admin.entity.Organization;
import com.softron.schema.admin.entity.Role;
import com.softron.schema.admin.repository.MenuRepository;
import com.softron.schema.admin.repository.OrganizationRepository;
import com.softron.schema.admin.repository.RoleRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class AdminService {

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private OrganizationRepository orgRepository;

	@Autowired
	private MenuRepository menuRepository;

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	ModelMapper modelMapper;

	String root = "Admin";

	//TODO: find last child leafs
	public Response getOrgLeaves(Long loggedUserOrgid) {
		try {
			Organization organization = organizationRepository.findByIdAndActiveTrue(loggedUserOrgid);
			OrganizationDto organizationDto = getOrgnizationDto(organization);
			List<OrganizationDto> results = new ArrayList<>();
			findOrganizationLeaves(organizationDto, results);
					
			return ResponseUtils.getSuccessResponse(HttpStatus.OK, results, String.format("All %ses", root));
		} catch (Exception e) {
			return ResponseUtils.getFailResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Internal error occured");
		}
	}
	
	//Recursive algo for finding last child organization
	public List<OrganizationDto> findOrganizationLeaves(OrganizationDto organizationDto, List<OrganizationDto> results) {
		List<OrganizationDto> organizationDtoList = getOrgnizationDtos(organizationRepository.findAllActive());		
		List<OrganizationDto> leaves = getLeaves(organizationDto, organizationDtoList, results);

		return leaves;
	}

	public List<OrganizationDto> getLeaves(OrganizationDto organizationDto, List<OrganizationDto> organizationDtoList, List<OrganizationDto> results) {
		List<OrganizationDto> childOrganizationDtos = getChildOfOrganization(organizationDto.getId(), organizationDtoList);
		
		if (childOrganizationDtos.isEmpty()) {
			results.add(organizationDto);
		} else {
			for (OrganizationDto childDto : childOrganizationDtos) {
				findOrganizationLeaves(childDto, results);
			}	
		}
		
		return results;
	}
	
	private OrganizationDto getOrgnizationDto(Organization organization) {
		OrganizationDto organizationDto = new OrganizationDto();
		organizationDto.setId(organization.getId());
		organizationDto.setName(organization.getName());
		organizationDto.setParentId(organization.getParentId());
		
		return organizationDto;
	}
	
	private List<OrganizationDto> getOrgnizationDtos(List<Organization> organizationList) {
		List<OrganizationDto> organizationDtoList = new ArrayList<>();
		for(Organization organization:organizationList) {
			OrganizationDto organizationDto = new OrganizationDto();
			organizationDto.setId(organization.getId());
			organizationDto.setName(organization.getName());
			organizationDto.setParentId(organization.getParentId());
			organizationDtoList.add(organizationDto);
		}
		
		return organizationDtoList;
	}
	
	private List<OrganizationDto> getChildOfOrganization(Long orgId, List<OrganizationDto> organizationDtoList) {
		return  organizationDtoList.stream()
				.filter(organizationDto -> orgId.equals(organizationDto.getParentId())).collect(Collectors.toList());
	}

	public Response getOrgAsCompanyId(Long orgId) {
		try {
//			Organization organizationDetail = organizationRepository.findOrganizationById(orgId);
			return ResponseUtils.getSuccessResponse(HttpStatus.OK, getOrgAsCompany(orgId),
					String.format("All %ses", root));
		} catch (Exception e) {
			return ResponseUtils.getFailResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Internal error occured");
		}
	}

	public Organization getOrgAsCompany(Long orgId) {
		Organization organization = organizationRepository.findOrganizationById(orgId);
		if (organization.getParentId() == null) {
			return organization;
		} else {
			return getOrgAsCompany(organization.getParentId());
		}
	}

	public List<Organization> getOrganizationList(Long orgId, List<Organization> result) {
		// List<Section> result = new ArrayList<Section>();
		try {
			// List<Organization> organizationList = organizationRepository.findAll(orgId);

			List<Organization> organizationChilds = organizationRepository.findByParentId(orgId);
			if(!organizationChilds.isEmpty()) {
				result.addAll(organizationChilds);
				for (Organization org : organizationChilds) {
					getOrganizationList(org.getId(), result);
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		return result;
	}

	/*
	 * ********** Organization CRUD Operations ******************
	 */

	public List<Organization> getActiveOrganizations() {
		return orgRepository.findAllActive();
	}

	public Response getOrganizations(Long parentId) {
		System.out.println(parentId);
		List<Organization> org = new ArrayList<Organization>();
		try {

			if (parentId != null) {
				System.out.println("parent here");
				org = orgRepository.findByParentId(parentId);
			} else {
				System.out.println("parent not here");
				org = orgRepository.findAllWithOutParentId();
			}

			return ResponseUtils.getSuccessResponse(HttpStatus.OK, org, String.format("All %ses", root));
		} catch (Exception e) {
			return ResponseUtils.getFailResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Internal error occured");
		}

	}

	public Response getAllOrganizations() {

		try {
			List<Organization> organizations = orgRepository.findAll();
			return ResponseUtils.getSuccessResponse(HttpStatus.OK, organizations, organizations.size(),
					String.format("All %ses", root));
		} catch (Exception e) {
			return ResponseUtils.getFailResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Internal error occured");
		}
	}

	public Organization getOrganizationById(Long id) {
		return orgRepository.findById(id)
				.orElseThrow(() -> new NoRecordExistsException("Organization doesn't exist for id=" + id));
	}

//	@Transactional(propagation = Propagation.REQUIRED)
//	public void saveOrganization(Organization org) {
//		orgRepository.save(org);
//		
//	}

	@Transactional(propagation = Propagation.REQUIRED)
	public Response saveOrganization(Organization org) {
		try {
			// Organization organization = modelMapper.map(org, Organization.class);
			if (org.getParentId() == null) {
				org.setRootPath("/" + org.getName());
			} else {
				Optional<Organization> parentRootpath = organizationRepository.findById(org.getParentId());
				org.setRootPath(parentRootpath.get().getRootPath() + "/" + org.getName());
			}
			orgRepository.save(org);
			return ResponseUtils.getSuccessResponse(HttpStatus.CREATED, org, String.format("All %ses", root));
		} catch (Exception e) {
			return ResponseUtils.getFailResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Internal error occured");
		}

	}

	public Response deleteOrganization(Long id) {
		try {
			Organization organization = orgRepository.findById(id).orElseThrow(
					() -> new NoRecordExistsException(String.format("%s doesn't exist for id %s", root, id)));
			organization.setActive(false);
			Organization organization1 = orgRepository.save(organization);
			OrganizationDto organizationDto = new OrganizationDto();
			BeanUtils.copyProperties(organization1,organizationDto,"section","workProcess","employee", "operation","defect","qualityTransaction","client","orderEntity","style","userEntity","operationMachine","targetAndManpower","capacityStudy","customer","qualityDefect","settings","device","machine","item","productionLight","lineWiseStyleInfo");

			return ResponseUtils.getSuccessResponse(HttpStatus.OK, organizationDto,
					String.format("%s deleted successfully", root));
		} catch (NoRecordExistsException e) {
			return ResponseUtils.getFailResponse(HttpStatus.NOT_FOUND, e.getMessage());
		} catch (Exception e) {
			return ResponseUtils.getFailResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Internal error occured");
		}

	}

	public List<Role> getActiveRoles() {
		return roleRepository.findAllActive();
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public void saveRole(RoleTO roleTO) {
		roleTO.setName(roleTO.getName().toUpperCase());
		if (roleTO.getId() == null && roleRepository.findByNameIgnoreCase(roleTO.getName()).isPresent()) {
			throw new RecordAlreadyExisting("Role name '" + roleTO.getName() + "' already existing in system.");
		}
		Role role = new Role();
		BeanUtils.copyProperties(roleTO, role);
		Set<Menu> permissions = menuRepository.findByIdIn(roleTO.getMenuIds());
		role.setPermittedMenus(permissions);
		roleRepository.save(role);
	}

	public List<Role> getAllRoles() {
		return roleRepository.findAll();
	}

	public RoleTO getRoleById(Long id) {
		Role role = roleRepository.findById(id)
				.orElseThrow(() -> new NoRecordExistsException("Role doesn't exist for id=" + id));
		RoleTO roleTO = new RoleTO();
		BeanUtils.copyProperties(role, roleTO);
		roleTO.setMenuIds(role.getPermittedMenus().stream().map(Menu::getId).collect(Collectors.toList()));
		return roleTO;
	}

	public List<Role> getRolesByModuleIds(final List<Long> moduleIds) {
		return roleRepository.findByModuleIds(moduleIds);
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public void deleteRole(Long id) {
		roleRepository.deleteById(id);
	}

//	@Transactional(propagation = Propagation.REQUIRED)
//	public void deleteRole(Long id) {
//		Role role = roleRepository.findById(id)
//				.orElseThrow(() -> new NoRecordExistsException("Role doesn't exist for id=" + id));
//		role.setActive(false);
//		roleRepository.save(role);
//	}

	private List<OrganizationDto> getResponseDtoList(List<Organization> organizations) {
		List<OrganizationDto> responseDtoList = new ArrayList<>();

		organizations.forEach(organization -> {
			OrganizationDto organizationDto = new OrganizationDto();
			modelMapper.map(organization, organizationDto);
			// BeanUtils.copyProperties(client, clientDto);
			responseDtoList.add(organizationDto);
		});
		return responseDtoList;
	}

}
