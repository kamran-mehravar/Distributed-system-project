package com.softron.admin.erlang.interfaces;

import java.util.List;

public interface RemoteErlang {
    // write a advertisement record to the database.
   String insertAdvertisement(AdvertisementDto advertisementDto) throws  RemoteErlangException;
}

