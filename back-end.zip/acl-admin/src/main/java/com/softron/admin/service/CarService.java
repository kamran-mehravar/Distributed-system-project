package com.softron.admin.service;

import com.softron.common.businessobjects.Response;

public interface CarService {
    Response count();
    Response getAll();
}
