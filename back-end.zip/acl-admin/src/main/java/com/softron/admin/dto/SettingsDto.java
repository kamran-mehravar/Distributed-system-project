package com.softron.admin.dto;

import java.time.LocalTime;

import javax.persistence.OneToOne;

import com.softron.schema.admin.entity.Organization;

import lombok.Data;

@Data
public class SettingsDto {
	
	private Long id;
	
	private String startTime;
	
	private String lunchTime;
	
	private Integer workingHours;

	private double lastDayWIP;

	//private Organization orgId;
	
}
