package com.softron.admin.erlang.controller;

import com.softron.admin.erlang.dto.AdvertisementExternalDto;
import com.softron.admin.erlang.dto.CarExternalDto;
import com.softron.admin.erlang.impl.ErlangService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/external")
public class RestApiCtrl {

    @Autowired
    ErlangService erlangService;
    @GetMapping("/advertisements")
    public ResponseEntity<List<AdvertisementExternalDto>> getAdvertisements(@RequestParam("title") String title) {
        System.out.println(title);
        List<AdvertisementExternalDto> ads = erlangService.getAdvertisements(title);
        if (ads.isEmpty()) {
            // Return 404 Not Found if the list is emptycd
            return ResponseEntity.notFound().build();
        } else {
            // Return 200 OK with the list of advertisements
            return ResponseEntity.ok(ads);
        }
    }

    @GetMapping("/allAdvertisements")
    public ResponseEntity<List<AdvertisementExternalDto>> getAllAdvertisements() {
        List<AdvertisementExternalDto> ads = erlangService.getAllAdvertisements();
        if (ads.isEmpty()) {
            // Return 404 Not Found if the list is emptycd
            return ResponseEntity.notFound().build();
        } else {
            // Return 200 OK with the list of advertisements
            return ResponseEntity.ok(ads);
        }
    }

    @PostMapping("/createAdvertisement")
    public ResponseEntity<List<AdvertisementExternalDto>> createAdvertisement(@RequestBody AdvertisementExternalDto dto) {
        List<AdvertisementExternalDto> ads = erlangService.createAdvertisement(dto);
        if (ads.isEmpty()) {
            // Return 404 Not Found if the list is emptycd
            return ResponseEntity.notFound().build();
        } else {
            // Return 200 OK with the list of advertisements
            return ResponseEntity.ok(ads);
        }
    }
    @GetMapping("/date")
    public ResponseEntity<String> getDate() {
        String date = erlangService.getDate();
        return ResponseEntity.ok(date);
    }


    @PostMapping("/createCar")
    public ResponseEntity<CarExternalDto> createCar(@RequestBody CarExternalDto dto) {
        CarExternalDto cars = erlangService.createCar(dto);
        if (cars==null) {
            // Return 404 Not Found if the list is emptycd
            return ResponseEntity.notFound().build();
        } else {
            // Return 200 OK with the list of advertisements
            return ResponseEntity.ok(cars);
        }
    }

    @GetMapping("/allCars")
    public ResponseEntity<List<CarExternalDto>> getAllCars() {
        List<CarExternalDto> cars = erlangService.getAllCars();
        if (cars.isEmpty()) {
            // Return 404 Not Found if the list is emptycd
            return ResponseEntity.notFound().build();
        } else {
            // Return 200 OK with the list of advertisements
            return ResponseEntity.ok(cars);
        }
    }
}
