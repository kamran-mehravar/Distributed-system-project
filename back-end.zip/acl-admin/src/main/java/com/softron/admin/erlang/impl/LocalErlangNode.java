package com.softron.admin.erlang.impl;

import com.ericsson.otp.erlang.OtpErlangRef;
import com.ericsson.otp.erlang.OtpMbox;
import com.ericsson.otp.erlang.OtpNode;
import com.softron.admin.erlang.interfaces.ErlangNode;
import com.softron.admin.erlang.interfaces.RemoteErlangException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.io.IOException;
import java.util.logging.Logger;

@Component
public class LocalErlangNode implements ErlangNode {
    private static final Logger logger = Logger.getLogger(LocalErlangNode.class.getName());
    private OtpNode node;
    private String clientName;
    private String cookie;

    @Value("${erlang.client_name}")
    private String erlangClientName;

    @Value("${erlang.cookie}")
    private String erlangCookie;

    @PostConstruct
    public void init(){
        logger.info("Init ErlangNode");
        // Load config parameters

        try{
            clientName = erlangClientName;
            cookie =  erlangCookie;
            //
            node = getNode();
        }
        catch(IOException ex){
            node = null;
            logger.warning(String.format("Can't create connection to Erlang Server: %s ", ex.getMessage()));
        }
    }

    private OtpNode getNode() throws IOException {
        // Check if node is already present
        if(node == null)
            return new OtpNode(clientName + "-" + this.hashCode(), cookie);
        else
            return node;
    }

    @Override
    public OtpMbox getMbox() throws RemoteErlangException {
        // Create new message box to exchange message with the Java Nodes.
        try{
           return getNode().createMbox();
        }
        catch (NullPointerException | IOException ex){
            node = null;
            throw new RemoteErlangException("getMbox_error");
        }
    }

    @Override
    public OtpErlangRef makeRef() throws RemoteErlangException {
        // Create unique reference to distinguish requests
        try{
            return getNode().createRef();
        }
        catch (NullPointerException | IOException ex){
            node = null;
            throw new RemoteErlangException("makeRef_error");
        }
    }

    @PreDestroy
    public void destroy() {
        logger.info("Destroy ErlangNode");
        if(node != null)
            node.close();
    }
}
