package com.softron.admin.service.impl;

import com.softron.admin.erlang.dto.AdvertisementExternalDto;
import com.softron.admin.erlang.dto.CarExternalDto;
import com.softron.admin.service.CarService;
import com.softron.common.businessobjects.Response;
import com.softron.common.utils.ResponseUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.NestedExceptionUtils;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;

@Service("carService")
@Slf4j
public class CarServiceImpl implements CarService {
    private final RestTemplate restTemplate;

    public CarServiceImpl(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Override
    public Response count() {
        return ResponseUtils.getSuccessResponse(HttpStatus.OK, 4, "Car Count");
    }

    @Override
    public Response getAll() {
        try {
            String url = "http://10.2.1.54:8081/api/v1/allCars";

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<?> requestEntity = new HttpEntity<>(headers);

            ResponseEntity<CarExternalDto[]> responseEntity = restTemplate.exchange(
                    url, HttpMethod.GET, requestEntity, CarExternalDto[].class);

            // Check if the request was successful (HTTP status code 2xx)
            if (responseEntity.getStatusCode().is2xxSuccessful()) {
                // Retrieve the array of AdvertisementExternalDto from the response
                CarExternalDto[] advertisementArray = responseEntity.getBody();

                // Convert the array to a List
                List<CarExternalDto> advertisementList = Arrays.asList(advertisementArray);

                return ResponseUtils.getSuccessResponse(HttpStatus.OK, advertisementList, advertisementList.size(), "Car list");
            } else {
                return ResponseUtils.getFailResponse(HttpStatus.NOT_FOUND, "Car not found");
            }
        } catch (Exception e) {
            log.error("Specific Cause: {}", NestedExceptionUtils.getMostSpecificCause(e));
            return ResponseUtils.getFailResponse(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while processing your request.");
        }
    }
}
