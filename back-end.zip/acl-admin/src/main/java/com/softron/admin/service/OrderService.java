package com.softron.admin.service;

import com.softron.admin.dto.OrderDto;
import com.softron.common.businessobjects.Response;
import org.springframework.data.domain.Pageable;

public interface OrderService {
    Response create(OrderDto orderDto);

    Response getAll(Pageable pageable, boolean isExport, String search, String status);
}
