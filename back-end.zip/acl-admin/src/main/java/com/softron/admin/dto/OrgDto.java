package com.softron.admin.dto;

import lombok.Data;

@Data
public class OrgDto {
	
	private Long id;
    private String name;
    private Boolean active;
    private String rootPath;
    private String code;
    private String address;
    private Boolean isLine;
    private Long parentId;
    private SettingsDto settings;
    
}
