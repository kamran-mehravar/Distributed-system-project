package com.softron.admin.erlang;

import com.ericsson.otp.erlang.*;

import java.io.IOException;

public class ErlangConnector {
    private OtpNode node;
    private OtpMbox mbox;
    //String nodeName = "car_server@localhost";
    String nodeName = "test_car_server@MSI";
    String cookie = "car_secret_cookie";

    public static void main(String[] args) {
        ErlangConnector erlangConnector = new ErlangConnector();
        erlangConnector.test();
        //erlangConnector.connect();
        //erlangConnector.sendMessage("process1", "Hello erlang");
        //erlangConnector.createPersonTable();
    }

    public void test() {
        OtpNode node = null;
        OtpMbox mbox;
        String nodeName = "car_server@localhost";
        String cookie = "car_secret_cookie";

        try {
            // Establish connection to Erlang node
            node = new OtpNode(nodeName, cookie);

            // Create table in Mnesia
            OtpErlangObject[] tableSpec = {
                    new OtpErlangAtom("your_table_name"),  // Table name
                    new OtpErlangList(new OtpErlangAtom[]{new OtpErlangAtom("column1"), new OtpErlangAtom("column2")}),  // Column names
                    new OtpErlangList(new OtpErlangAtom[]{new OtpErlangAtom("string"), new OtpErlangAtom("integer")}),  // Column types
                    new OtpErlangAtom("set"),  // Table type
                    new OtpErlangAtom("public")  // Access mode
            };
            OtpErlangObject createTableMsg = new OtpErlangTuple(new OtpErlangObject[]{
                    new OtpErlangAtom("create_table"),
                    new OtpErlangList(tableSpec)
            });

            mbox = node.createMbox();
            mbox.send("mnesia", "mnesia_controller", createTableMsg);

            // Handle response
            OtpErlangObject response = mbox.receive();
            if (response instanceof OtpErlangAtom && response.equals(new OtpErlangAtom("ok"))) {
                System.out.println("Table created successfully");
            } else {
                System.out.println("Table creation failed");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            node.close();
        }
    }
    public void createPersonTable() {


        try {
            // Establish connection to Erlang node
            node = new OtpNode(nodeName, cookie);
            // Create table in Mnesia
            OtpErlangObject[] tableSpec = {
                    new OtpErlangAtom("person_table"),  // Table name
                    new OtpErlangList(new OtpErlangAtom[]{new OtpErlangAtom("name"), new OtpErlangAtom("age")}),  // Column names
                    new OtpErlangList(new OtpErlangAtom[]{new OtpErlangAtom("string"), new OtpErlangAtom("integer")}),  // Column types
                    new OtpErlangAtom("set"),  // Table type
                    new OtpErlangAtom("public")  // Access mode
            };
            OtpErlangObject createTableMsg = new OtpErlangTuple(new OtpErlangObject[]{
                    new OtpErlangAtom("create_table"),
                    new OtpErlangList(tableSpec)
            });
            mbox = node.createMbox();
            mbox.send("mnesia", "mnesia_controller", createTableMsg);

            /*// Encode person information
            OtpErlangObject[] personData = {
                    new OtpErlangString("John Doe"),
                    new OtpErlangInt(30)
            };
            OtpErlangTuple encodedData = new OtpErlangTuple(personData);

            // Insert data into Mnesia
            OtpErlangObject[] insertMsg = {
                    new OtpErlangAtom("insert"),
                    new OtpErlangAtom("person_table"),
                    encodedData
            };
            mbox.send("mnesia", "transaction_manager", new OtpErlangTuple(insertMsg));*/

            // Handle response
            OtpErlangObject response = mbox.receive();
            if (response instanceof OtpErlangAtom && response.equals(new OtpErlangAtom("ok"))) {
                System.out.println("Data inserted successfully");
            } else {
                System.out.println("Data insertion failed");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            node.close();
        }
    }

    public void connect() {
        try {
            String cookie = "car_secret_cookie";
            String nodeId = "client_node@127.0.0.1";
            String mailBoxId = "MyMailBox";
            OtpNode node = new OtpNode(nodeId, cookie);

            OtpMbox mailBox = node.createMbox(mailBoxId);

            String serverMailBoxId = "car_serverMailBox";
            String serverNodeId = "car_server@127.0.0.1";
            OtpErlangObject[] content = new OtpErlangObject[2];
            content[0] = mailBox.self();
            content[1] = new OtpErlangString("James");
            OtpErlangTuple message = new OtpErlangTuple(content);
            //mailBox.send(serverMailBoxId, serverNodeId, message);
            mailBox.send(serverMailBoxId, nodeId, message);

            System.out.println("mailBox: " + mailBox.toString());

            OtpErlangObject newMessage = mailBox.receive();
            if (newMessage instanceof OtpErlangTuple) {
                OtpErlangTuple erlangTuple = (OtpErlangTuple) newMessage;
                OtpErlangPid senderPID = (OtpErlangPid) erlangTuple.elementAt(0);
                OtpErlangString clientName = (OtpErlangString) erlangTuple.elementAt(1);
                String messageStr = "Hello " + clientName.stringValue();
                OtpErlangString greetings = new OtpErlangString(messageStr);
                mailBox.send(senderPID, greetings);
            }
        } catch (OtpErlangDecodeException e) {
            throw new RuntimeException(e);
        } catch (OtpErlangExit e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
        public void connect1() {
        try {
            // Provide the hostname and cookie for the Erlang node


            // Create and connect to the Erlang node
            //node = new OtpNode(nodeName, cookie);
            node = new OtpNode(nodeName);
            mbox = node.createMbox();

            OtpErlangObject[] msg = new OtpErlangObject[2];
            msg[0] = mbox.self();
            msg[1] = new OtpErlangAtom("hello, world");
            OtpErlangTuple tuple = new OtpErlangTuple(msg);

            mbox.send("echo", nodeName, tuple);
            System.out.println("Mbox id: " + mbox.self().id());
            OtpErlangObject reply = mbox.receive();


            System.out.println("Reply: " + reply.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void sendMessage(String recipient, String message) {
        try {
            // Create an OtpErlangAtom representing the recipient's Erlang process name
            OtpErlangAtom recipientAtom = new OtpErlangAtom(recipient);

            // Create an OtpErlangString representing the message to be sent
            OtpErlangString messageString = new OtpErlangString(message);

            // Create an OtpErlangTuple containing the recipient and message
            OtpErlangTuple tuple = new OtpErlangTuple(new OtpErlangObject[]{recipientAtom, messageString});

            // Send the message using the mbox's send method
            mbox.send("mnesia_node", "my_erlang_process", tuple);

            System.out.println("Message sent: " + message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}