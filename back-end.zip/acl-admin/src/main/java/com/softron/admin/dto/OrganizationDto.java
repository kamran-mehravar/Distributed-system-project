package com.softron.admin.dto;

import lombok.Data;

@Data
public class OrganizationDto{

    private Long id;

    private String name;
    
    private String head;
    
    private String code;
    
    private String type;
    
    private String rootPath;
    
    private String nameEng;

    private String nameBang;

    private String webAddress;

    private String telephone;

    private String address;

    private String email;

    private String remarks;

    private Boolean active;

    private Long orgType;

    private Long locationId;

    private Long parentId;
    
//    private List<SectionDto> section;
    
    private SettingsDto settings;

  
}
