package com.softron.admin.erlang.dto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.softron.admin.dto.UserDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AdvertisementExternalDto {
    private String id;
    private String title;
    private String description;
    private String price;
    private String region;
    private String manufacturer;
    private String productionYear;
    private String username;
    private UserDto user;
}