package com.softron.admin.service.impl;

import com.softron.admin.dto.OrderDto;
import com.softron.admin.service.OrderService;
import com.softron.common.businessobjects.Response;
import com.softron.common.utils.AuthUtil;
import com.softron.common.utils.ResponseUtils;
import com.softron.core.constants.OrderStatusConstants;
import com.softron.schema.admin.entity.Order;
import com.softron.schema.admin.entity.UserEntity;
import com.softron.schema.admin.repository.AdvertisementRepository;
import com.softron.schema.admin.repository.OrderRepository;
import com.softron.schema.admin.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.core.NestedExceptionUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service("orderService")
@Slf4j
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final ModelMapper modelMapper;
    private final UserRepository userRepository;
    private final AdvertisementRepository advertisementRepository;
    private final EntityManager entityManager;

    public OrderServiceImpl(OrderRepository orderRepository, ModelMapper modelMapper, UserRepository userRepository, AdvertisementRepository advertisementRepository, EntityManager entityManager) {
        this.orderRepository = orderRepository;
        this.modelMapper = modelMapper;
        this.userRepository = userRepository;
        this.advertisementRepository = advertisementRepository;
        this.entityManager = entityManager;
    }

    @Override
    public Response create(OrderDto orderDto) {
        try {
            String username = AuthUtil.getUserName();
            Order order = new Order();
            BeanUtils.copyProperties(orderDto, order);
            UserEntity user = userRepository.getOne(username);
            order.setUsername(user.getUserName());
            order.setStatus(OrderStatusConstants.PENDING);
            order.setOrderDate(new Date());
            //Advertisement advertisement = advertisementRepository.findByIdAndIsActiveTrue(orderDto.getAdvertisement().getId());
            order.setTitle(orderDto.getAdvertisement().getTitle());
            order = orderRepository.save(order);
            return ResponseUtils.getSuccessResponse(HttpStatus.CREATED, null, "Order created successfully");
        } catch (Exception e) {
            log.error("Specific Cause: {}", NestedExceptionUtils.getMostSpecificCause(e));
            return ResponseUtils.getFailResponse(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while processing your request.");
        }
    }

    @Override
    public Response getAll(Pageable pageable, boolean isExport, String search, String status) {
        search = AuthUtil.getUserName();
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Order> criteriaQuery = criteriaBuilder.createQuery(Order.class);
        Root<Order> rootEntity = criteriaQuery.from(Order.class);
        addPredicates(criteriaBuilder, criteriaQuery, rootEntity, search);
        TypedQuery<Order> typedQuery = entityManager.createQuery(criteriaQuery);
        return getAllResponse(criteriaQuery, typedQuery, pageable, isExport);
    }

    private Response getAllResponse(CriteriaQuery<Order> criteriaQuery, TypedQuery<Order> typedQuery, Pageable pageable, boolean isExport) {
        long totalRows = this.getTotalRows(criteriaQuery);
        if (!isExport){
            typedQuery.setFirstResult(pageable.getPageNumber() * pageable.getPageSize());
            typedQuery.setMaxResults(pageable.getPageSize());
        }
        long rows = typedQuery.getResultList().size();
        Page<Order> pages = new PageImpl<>(typedQuery.getResultList(), pageable, rows);

        if (!pages.hasContent()){
            return ResponseUtils.getFailResponse(HttpStatus.NOT_FOUND, "Advertisement not found");
        }
        List<OrderDto> responseDtos = this.getResponseDtoList(pages);
        return ResponseUtils.getSuccessResponse(HttpStatus.OK, responseDtos, (int)totalRows, "Advertisement list");
    }

    private List<OrderDto> getResponseDtoList(Page<Order> pages) {
        return getResponseDtoList(pages.getContent());
    }

    private List<OrderDto> getResponseDtoList(List<Order> list){
        List<OrderDto> responseDtos = new ArrayList<>();
        list.forEach(item -> {
            OrderDto dto = modelMapper.map(item, OrderDto.class);
            dto.setUsername(item.getUsername());
            responseDtos.add(dto);
        });
        return responseDtos;
    }

    private long getTotalRows(CriteriaQuery<Order> criteriaQuery) {
        TypedQuery<Order> typedQuery = entityManager.createQuery(criteriaQuery);
        return typedQuery.getResultList().size();
    }

    private void addPredicates(CriteriaBuilder criteriaBuilder, CriteriaQuery<Order> criteriaQuery, Root<Order> rootEntity, String search) {
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(criteriaBuilder.isTrue(rootEntity.get("isActive")));
        if (search != null && search.trim().length() > 0) {
            Predicate pLike = criteriaBuilder.or(
                    criteriaBuilder.like(rootEntity.get("status"), "%" + search + "%"),
                    criteriaBuilder.equal(rootEntity.get("username"), search));
            predicates.add(pLike);
        }
        if (predicates.isEmpty()) {
            criteriaQuery.select(rootEntity);
        } else {
            criteriaQuery.select(rootEntity).where(predicates.toArray(new Predicate[0]));
        }
    }

}
