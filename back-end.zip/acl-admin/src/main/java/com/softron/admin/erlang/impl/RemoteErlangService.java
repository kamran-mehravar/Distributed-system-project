package com.softron.admin.erlang.impl;

import com.ericsson.otp.erlang.*;
import com.softron.admin.erlang.interfaces.AdvertisementDto;
import com.softron.admin.erlang.interfaces.ErlangNode;
import com.softron.admin.erlang.interfaces.RemoteErlang;
import com.softron.admin.erlang.interfaces.RemoteErlangException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.logging.Logger;

@Component
public class RemoteErlangService implements RemoteErlang {
    private static final Logger logger = Logger.getLogger(RemoteErlangService.class.getName());

    @Value("${erlang.server_name}")
    private String erlangServerName;

    @Value("${erlang.server_mailBox}")
    private String erlangServerMailBox;

    @Value("${erlang.cookie}")
    private String erlangCookie;

    @Value("${erlang.client_name}")
    private String erlangClientName;

    @Value("${erlang.client_mailBox}")
    private String erlangClientMailBox;

    @Value("${erlang.timeout:5000}")
    private int erlangTimeout;

    @Value("${erlang.bad_file}")
    private String erlangBadFile;

    @Value("${erlang.file_not_found}")
    private String erlangFileNotFound;

    @Value("${erlang.not_found_or_empty}")
    private String erlangNotFoundOrEmpty;

    @Value("${erlang.server_unavailable}")
    private String erlangServerUnavailable;

    @Value("${erlang.unknown_error}")
    private String erlangUnknownError;

    @Value("${erlang.contestid_lenght}")
    private int erlangContestIdLength;

    //This is the Local EJB for the to get a Node
    @Autowired
    private ErlangNode erlangNode;


    public String createAdvertisementTable() {
        String response = "Started";
        try {
            OtpErlangObject[] tableSpec = {
                    new OtpErlangAtom("advertisement"),  // Table name
                    new OtpErlangList(new OtpErlangAtom[]{new OtpErlangAtom("title"), new OtpErlangAtom("description"), new OtpErlangAtom("region")}),  // Column names
                    new OtpErlangList(new OtpErlangAtom[]{new OtpErlangAtom("string"), new OtpErlangAtom("string"), new OtpErlangAtom("string")}),  // Column types
                    new OtpErlangAtom("set"),  // Table type
                    new OtpErlangAtom("public")  // Access mode
            };
            OtpErlangTuple createTableMsg = new OtpErlangTuple(new OtpErlangObject[]{
                    new OtpErlangAtom("create_table"),
                    new OtpErlangList(tableSpec)
            });

            response = request_handler(createTableMsg);
        } catch (Exception e) {
            response = "Failed";
            e.printStackTrace();
        } finally {

        }
        return response;
    }

    public String saveAdvertisement(AdvertisementDto advertisementDto) {
        try {
            String title = advertisementDto.getTitle();
            String description = advertisementDto.getDescription();
            String region = advertisementDto.getRegion();

            // Check if any of the fields is null or empty
            if (title == null || description == null || region == null || title.isEmpty() || description.isEmpty() || region.isEmpty()) {
                throw new IllegalArgumentException("All fields must be provided");
            }

            // Create the data to be inserted as an Erlang Tuple
            OtpErlangObject[] advertisementData = {
                    new OtpErlangAtom("insert"),  // Operation type
                    new OtpErlangString(title),
                    new OtpErlangString(description),
                    new OtpErlangString(region)
            };
            OtpErlangTuple advertisementDataTuple = new OtpErlangTuple(advertisementData);

            // Create the message to send to the server
            OtpErlangTuple message = new OtpErlangTuple(new OtpErlangObject[]{
                    new OtpErlangAtom("advertisement"),  // Table name
                    advertisementDataTuple
            });

            // Send the message and receive the response from the server
            String response = request_handler(message);

            return response;
        } catch (Exception e) {
            e.printStackTrace();
            return "Failed";
        }
    }


    private String request_handler(OtpErlangTuple request) throws RemoteErlangException {
        String result = "";
        try {
            // This is a unique reference to identify a particular request.
            OtpErlangRef otpErlangRef = erlangNode.makeRef();
            // get a mail-box for the client.
            OtpMbox clientMailBox = erlangNode.getMbox();
            //
            // Send Request to Erlang Server.
            String serverMailBox = erlangServerMailBox;
            String serverName = erlangServerName;
            //
            OtpErlangObject[] content = new OtpErlangObject[3];
            content[0] = clientMailBox.self();
            content[1]=otpErlangRef;
            content[2]= request;
            OtpErlangTuple  message = new OtpErlangTuple(content);
            //
            // {serverMailBox, serverName} ! {clientMailBox.self(),otpErlangRef,request}
            //where request = {insert,Name,Surname,Contestid,Tally}
            //
            clientMailBox.send(serverMailBox,serverName,message);
            // Receive response.
            Integer time_out = erlangTimeout;
            OtpErlangObject response = clientMailBox.receive(time_out);
            // close the clientMailBox
            clientMailBox.close();
            //
            // Check and Parse Response
            if(response instanceof OtpErlangTuple && ((OtpErlangTuple) response).arity() == 2) {
                OtpErlangObject[] response_objs = ((OtpErlangTuple) response).elements();
                if (otpErlangRef.equals(response_objs[0]) && response_objs[1] instanceof OtpErlangTuple){
                    OtpErlangRef ref_x = (OtpErlangRef)response_objs[0];
                    // for the rest of the requests
                    result = String.valueOf(response_objs[1]);
                }
                else{
                    throw new RemoteErlangException("receives_bad_types");
                }
            }
            else{
                throw new RemoteErlangException("response_not_tuple_or_arity_not_2_OR_Server_is_down");
            }
        }
        catch (OtpErlangDecodeException | OtpErlangExit ex){
            ex.printStackTrace();
        }
        return result;
    }

    @Override
    public String insertAdvertisement(AdvertisementDto advertisementDto) throws RemoteErlangException {
        OtpErlangAtom request_atom = new OtpErlangAtom("insert");
        OtpErlangTuple message;

        String title = advertisementDto.getTitle();
        String description = advertisementDto.getDescription();
        String region = advertisementDto.getRegion();

        if (title != null && description != null && region != null) {
            OtpErlangObject[] advertisementDetails = new OtpErlangObject[4];
            advertisementDetails[0] = request_atom;
            advertisementDetails[1] = new OtpErlangString(title);
            advertisementDetails[2] = new OtpErlangString(description);
            advertisementDetails[3] = new OtpErlangString(region);
            // create a tuple of these values
            message = new OtpErlangTuple(advertisementDetails);
        } else {
            throw new RemoteErlangException("An empty field isn't allowed");
        }

        return request_handler(message);
    }

}