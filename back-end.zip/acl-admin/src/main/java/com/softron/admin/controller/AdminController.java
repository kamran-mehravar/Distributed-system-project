package com.softron.admin.controller;

import com.softron.core.annotations.ApiController;

@ApiController
public class AdminController {

}
