package com.softron.admin.dto;

import lombok.Data;

@Data
public class AdvertisementDto {
    private Long id;

    private String title;
    private String description;
    private double price;
    private String region;
    private String manufacturer;
    private int productionYear;

    private UserDto user;
    private Boolean isActive = true;
}
