package com.softron.admin.dto;

import com.softron.admin.erlang.dto.AdvertisementExternalDto;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
public class OrderDto {
    private Long id;
    private AdvertisementExternalDto advertisement;
    private String username;
    private String title;
    private String status;
    private Date orderDate;
    private Boolean isActive = true;
}
