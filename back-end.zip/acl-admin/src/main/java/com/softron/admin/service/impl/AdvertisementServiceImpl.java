package com.softron.admin.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.softron.admin.dto.AdvertisementDto;
import com.softron.admin.dto.UserDto;
import com.softron.admin.erlang.dto.AdvertisementExternalDto;
import com.softron.admin.service.AdvertisementService;
import com.softron.common.businessobjects.Response;
import com.softron.common.utils.AuthUtil;
import com.softron.common.utils.ResponseUtils;
import com.softron.schema.admin.entity.Advertisement;
import com.softron.schema.admin.entity.UserEntity;
import com.softron.schema.admin.repository.AdvertisementRepository;
import com.softron.schema.admin.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.core.NestedExceptionUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.*;

@Service("advertisementService")
@Slf4j
public class AdvertisementServiceImpl implements AdvertisementService {

    private final AdvertisementRepository advertisementRepository;
    private final UserRepository userRepository;
    private final ModelMapper modelMapper;
    private final EntityManager entityManager;
    private final RestTemplate restTemplate;

    public AdvertisementServiceImpl(AdvertisementRepository advertisementRepository, UserRepository userRepository,
                                    ModelMapper modelMapper, EntityManager entityManager, RestTemplate restTemplate) {
        this.advertisementRepository = advertisementRepository;
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
        this.entityManager = entityManager;
        this.restTemplate = restTemplate;
    }

    @Override
    public Response create(AdvertisementExternalDto advertisementDto) {
        advertisementDto.setUsername(AuthUtil.getUserName());
        advertisementDto.setId(UUID.randomUUID().toString());
        try {

            ObjectMapper objectMapper = new ObjectMapper();
            String jsonPayload = objectMapper.writeValueAsString(advertisementDto);

            String url = "http://10.2.1.54:8081/api/v1/advertisements";

            // Set the headers
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            // Set the request entity (payload)
            HttpEntity<String> requestEntity = new HttpEntity<>(jsonPayload, headers);

            // Create a RestTemplate instance
            RestTemplate restTemplate = new RestTemplate();

            // Send the POST request and get the response
            ResponseEntity<String> response = restTemplate.postForEntity(url, requestEntity, String.class);
            return ResponseUtils.getSuccessResponse(HttpStatus.CREATED, null, "Advertisement created successfully");
            // Return the response
            //return response.getBody();

            //return ResponseUtils.getSuccessResponse(HttpStatus.CREATED, null, "Advertisement created successfully");
        } catch (Exception e) {
            log.error("Specific Cause: {}", NestedExceptionUtils.getMostSpecificCause(e));
            return ResponseUtils.getFailResponse(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while processing your request.");
        }
    }

    public Response saveToMysql(AdvertisementDto advertisementDto) {
        try {
            Advertisement advertisement = new Advertisement();
            BeanUtils.copyProperties(advertisementDto, advertisement);
            UserEntity user = userRepository.getOne(advertisementDto.getUser().getUserName());
            advertisement.setUser(user);
            advertisement = advertisementRepository.save(advertisement);
            return ResponseUtils.getSuccessResponse(HttpStatus.CREATED, null, "Advertisement created successfully");
        } catch (Exception e) {
            log.error("Specific Cause: {}", NestedExceptionUtils.getMostSpecificCause(e));
            return ResponseUtils.getFailResponse(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while processing your request.");
        }
    }

    @Override
    public Response update(String id, AdvertisementExternalDto advertisementDto) {
        try {
            // Prepare the URL for the update request
            String url = "http://10.2.1.54:8081/api/v1/advertisements/" + id;

            // Map the DTO to the external DTO
            /*AdvertisementExternalDto advertisementExternalDto = new AdvertisementExternalDto();
            modelMapper.getConfiguration().setPropertyCondition(Conditions.isNotNull());
            modelMapper.map(advertisementDto, advertisementExternalDto);*/

            /*String username = Optional.ofNullable(advertisementDto.getUser())
                    .map(UserDto::getUserName)
                    .orElse("");

            advertisementExternalDto.setUsername(username);*/
            advertisementDto.setUsername(AuthUtil.getUserName());

            // Set the headers
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            // Set the request entity (payload)
            HttpEntity<AdvertisementExternalDto> requestEntity = new HttpEntity<>(advertisementDto, headers);

            // Create a RestTemplate instance
            RestTemplate restTemplate = new RestTemplate();

            // Send the PUT request and get the response
            restTemplate.exchange(url, HttpMethod.PUT, requestEntity, String.class);

            return ResponseUtils.getSuccessResponse(HttpStatus.OK, null, "Advertisement updated successfully");
        } catch (HttpClientErrorException.NotFound e) {
            return ResponseUtils.getFailResponse(HttpStatus.NOT_FOUND, "Advertisement not found with the provided ID.");
        } catch (Exception e) {
            log.error("Specific Cause: {}", NestedExceptionUtils.getMostSpecificCause(e));
            return ResponseUtils.getFailResponse(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while processing your request.");
        }
    }


    public Response updateToMysql(Long id, AdvertisementDto advertisementDto) {
        Advertisement advertisement = advertisementRepository.findByIdAndIsActiveTrue(id);
        if (advertisement == null) {
            return ResponseUtils.getFailResponse(HttpStatus.NOT_FOUND, "Requested advertisement not found");
        }
        try {
            modelMapper.getConfiguration().setPropertyCondition(Conditions.isNotNull());
            modelMapper.map(advertisementDto, advertisement);
            if (advertisementDto.getUser() != null) {
                UserEntity user = userRepository.getOne(advertisementDto.getUser().getUserName());
                advertisement.setUser(user);
            }
            advertisementRepository.save(advertisement);
            return ResponseUtils.getSuccessResponse(HttpStatus.OK, null, "Advertisement successfully updated.");
        } catch (Exception e) {
            log.error("Specific Cause: {}", NestedExceptionUtils.getMostSpecificCause(e));
            return ResponseUtils.getFailResponse(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while processing your request.");
        }
    }

    @Override
    public Response get(Long id) {
        Advertisement advertisement = advertisementRepository.findByIdAndIsActiveTrue(id);
        if (advertisement == null) {
            return ResponseUtils.getFailResponse(HttpStatus.NOT_FOUND, "Requested advertisement could not be found");
        }
        try {
            AdvertisementDto advertisementDto = modelMapper.map(advertisement, AdvertisementDto.class);
            if (advertisementDto != null) {
                return ResponseUtils.getSuccessResponse(HttpStatus.OK, advertisementDto, "Advertisement retrieved successfully");
            }
            return ResponseUtils.getFailResponse(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while processing your request.");
        } catch (Exception e) {
            log.error("Specific Cause: {}", NestedExceptionUtils.getMostSpecificCause(e));
            return ResponseUtils.getFailResponse(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while processing your request.");
        }
    }

    @Override
    public Response getAll(Pageable pageable, boolean isExport, String search, String status) {
        try {
            String url = "http://10.2.1.54:8081/api/v1/advertisements";

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<?> requestEntity = new HttpEntity<>(headers);

            ResponseEntity<AdvertisementExternalDto[]> responseEntity = restTemplate.exchange(
                    url, HttpMethod.GET, requestEntity, AdvertisementExternalDto[].class);

            // Check if the request was successful (HTTP status code 2xx)
            if (responseEntity.getStatusCode().is2xxSuccessful()) {
                // Retrieve the array of AdvertisementExternalDto from the response
                AdvertisementExternalDto[] advertisementArray = responseEntity.getBody();

                // Convert the array to a List
                List<AdvertisementExternalDto> advertisementList = Arrays.asList(advertisementArray);

                return ResponseUtils.getSuccessResponse(HttpStatus.OK, advertisementList, advertisementList.size(), "Advertisement list");
            } else {
                return ResponseUtils.getFailResponse(HttpStatus.NOT_FOUND, "Advertisement not found");
            }
        } catch (Exception e) {
            log.error("Specific Cause: {}", NestedExceptionUtils.getMostSpecificCause(e));
            return ResponseUtils.getFailResponse(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while processing your request.");
        }
    }

    public Response getAllFromMySql(Pageable pageable, boolean isExport, String search, String status) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Advertisement> criteriaQuery = criteriaBuilder.createQuery(Advertisement.class);
        Root<Advertisement> rootEntity = criteriaQuery.from(Advertisement.class);
        addPredicates(criteriaBuilder, criteriaQuery, rootEntity, search);
        TypedQuery<Advertisement> typedQuery = entityManager.createQuery(criteriaQuery);
        return getAllResponse(criteriaQuery, typedQuery, pageable, isExport);
    }

    private Response getAllResponse(CriteriaQuery<Advertisement> criteriaQuery, TypedQuery<Advertisement> typedQuery, Pageable pageable, boolean isExport) {
        long totalRows = this.getTotalRows(criteriaQuery);
        if (!isExport){
            typedQuery.setFirstResult(pageable.getPageNumber() * pageable.getPageSize());
            typedQuery.setMaxResults(pageable.getPageSize());
        }
        long rows = typedQuery.getResultList().size();
        Page<Advertisement> pages = new PageImpl<>(typedQuery.getResultList(), pageable, rows);

        if (!pages.hasContent()){
            return ResponseUtils.getFailResponse(HttpStatus.NOT_FOUND, "Advertisement not found");
        }
        List<AdvertisementDto> responseDtos = this.getResponseDtoList(pages);
        return ResponseUtils.getSuccessResponse(HttpStatus.OK, responseDtos, (int)totalRows, "Advertisement list");
    }

    private List<AdvertisementDto> getResponseDtoList(Page<Advertisement> pages) {
        return getResponseDtoList(pages.getContent());
    }

    private List<AdvertisementDto> getResponseDtoList(List<Advertisement> list){
        List<AdvertisementDto> responseDtos = new ArrayList<>();
        list.forEach(item -> {
            AdvertisementDto dto = modelMapper.map(item, AdvertisementDto.class);
            responseDtos.add(dto);
        });
        return responseDtos;
    }

    private long getTotalRows(CriteriaQuery<Advertisement> criteriaQuery) {
        TypedQuery<Advertisement> typedQuery = entityManager.createQuery(criteriaQuery);
        return typedQuery.getResultList().size();
    }

    private void addPredicates(CriteriaBuilder criteriaBuilder, CriteriaQuery<Advertisement> criteriaQuery, Root<Advertisement> rootEntity, String search) {
        List<Predicate> predicates = new ArrayList<>();
        predicates.add(criteriaBuilder.isTrue(rootEntity.get("isActive")));
        if (search != null && search.trim().length() > 0) {
            Predicate pLike = criteriaBuilder.or(
                    criteriaBuilder.like(rootEntity.get("title"), "%" + search + "%"),
                    criteriaBuilder.like(rootEntity.get("description"), "%" + search + "%"),
                    criteriaBuilder.like(rootEntity.get("region"), "%" + search + "%"),
                    criteriaBuilder.like(rootEntity.get("manufacturer"), "%" + search + "%")
                    /*,
                    criteriaBuilder.like(rootEntity.get("productionYear"), "%" + search + "%"),
                    criteriaBuilder.like(rootEntity.get("price"), "%" + search + "%")*/);
            predicates.add(pLike);
        }
        if (predicates.isEmpty()) {
            criteriaQuery.select(rootEntity);
        } else {
            criteriaQuery.select(rootEntity).where(predicates.toArray(new Predicate[0]));
        }
    }

    @Override
    public Response delete(String id) {
        try {
            // Prepare the URL for the delete request
            String url = "http://10.2.1.54:8081/api/v1/advertisements/" + id;

            // Set the headers
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            // Create a RestTemplate instance
            RestTemplate restTemplate = new RestTemplate();

            // Set the request entity (payload) to be empty for DELETE request
            HttpEntity<String> requestEntity = new HttpEntity<>(headers);

            // Send the DELETE request and get the response
            restTemplate.exchange(url, HttpMethod.DELETE, requestEntity, String.class);

            return ResponseUtils.getSuccessResponse(HttpStatus.OK, null, "Advertisement deleted successfully");
        } catch (HttpClientErrorException.NotFound e) {
            return ResponseUtils.getFailResponse(HttpStatus.NOT_FOUND, "Advertisement not found with the provided ID.");
        } catch (Exception e) {
            log.error("Specific Cause: {}", NestedExceptionUtils.getMostSpecificCause(e));
            return ResponseUtils.getFailResponse(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while processing your request.");
        }
    }

    public Response deleteMysql(Long id) {
        Advertisement advertisement = advertisementRepository.findByIdAndIsActiveTrue(id);
        if (advertisement == null){
            return ResponseUtils.getFailResponse(HttpStatus.NOT_FOUND, "Requested advertisement could not be found");
        }
        try {
            advertisement.setIsActive(false);
            advertisementRepository.save(advertisement);
            return ResponseUtils.getSuccessResponse(HttpStatus.OK, null, "Advertisement deleted successfully.");
        } catch (Exception e){
            log.error("Specific Cause: {}", NestedExceptionUtils.getMostSpecificCause(e));
            return ResponseUtils.getFailResponse(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while processing your request.");
        }
    }
}
