package com.softron.admin.erlang.interfaces;

import com.ericsson.otp.erlang.OtpErlangRef;
import com.ericsson.otp.erlang.OtpMbox;

public interface ErlangNode {
    OtpMbox getMbox() throws RemoteErlangException;
    OtpErlangRef makeRef() throws RemoteErlangException;
}










