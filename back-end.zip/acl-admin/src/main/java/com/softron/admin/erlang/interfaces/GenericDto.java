package com.softron.admin.erlang.interfaces;

public abstract class GenericDto {

}

