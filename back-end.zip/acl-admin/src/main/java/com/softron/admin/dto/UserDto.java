package com.softron.admin.dto;

import lombok.Data;

@Data
public class UserDto {
    private String userName;
}
