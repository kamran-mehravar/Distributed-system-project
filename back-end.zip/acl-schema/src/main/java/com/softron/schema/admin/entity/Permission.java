package com.softron.schema.admin.entity;

import com.softron.datastore.Auditable;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "USER_PERMISSION")
@Data
@EqualsAndHashCode(callSuper = false)
public class Permission extends Auditable<String> implements Serializable {

    private static final long serialVersionUID = 8645976870237473739L;


    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "id_Sequence")
    @SequenceGenerator(name = "id_Sequence", sequenceName = "ID_SEQ")
    @Column(name = "PERMISSION_ID")
    private Long id;

    @Column(name = "PERMISSION_NAME")
    private String name;

    @Column(name = "ACTIVE", nullable = false)
    private boolean active;

    public Permission() {
    }

    public Permission( String name) {
        this.name = name;
    }
}
