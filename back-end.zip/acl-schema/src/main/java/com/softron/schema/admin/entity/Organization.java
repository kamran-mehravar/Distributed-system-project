package com.softron.schema.admin.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.softron.datastore.Auditable;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@JsonIgnoreProperties({ "section","workProcess","employee", "operation","defect","qualityTransaction","client","orderEntity","style","userEntity","operationMachine","targetAndManpowers","settings","qualityDefect","reportLayout","capacityStudy","device","machine","item" })
@Entity
@Table(name = "ORGANIZATIONS")
@Data
public class Organization extends Auditable<String> implements Serializable {

    private static final long serialVersionUID = 3857732116399697935L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "id_Sequence")
    @SequenceGenerator(name = "id_Sequence", sequenceName = "ID_SEQ")
    @Column(name = "ID")
    private Long id;

    @Column(name = "NAME")
    private String name;
    
    @Column(name = "HEAD")
    private String head;
    
    @Column(name = "CODE")
    private String code;
    
    @Column(name = "TYPE")
    private String type;
    
    @Column(name = "NAME_ENGLISH")
    private String nameEng;

    @Column(name = "NAME_BANGLA")
    private String nameBang;

    @Column(name = "WEB_ADDRESS")
    private String webAddress;

    @Column(name = "TELEPHONE")
    private String telephone;

    @Column(name = "ADDRESS")
    private String address;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "REMARKS")
    private String remarks;

    @Column(name = "ACTIVE")
    private boolean active;

    @Column(name = "ORG_TYPE")
    private Long orgType;

    @Column(name = "LOCATION_ID")
    private Long locationId;

    @Column(name = "PARENT_ORG")
    private Long parentId;
    
    @Column(name = "ROOT_PATH")
    private String rootPath;
    
    @Column(name = "IS_LINE")
    private Boolean isLine;
    
    @PrePersist
	public void prePersist() {
		this.isLine = false;
	}
}
