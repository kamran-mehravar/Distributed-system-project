package com.softron.schema.admin.entity;

import com.softron.datastore.Auditable;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "CAR")
@Data
public class Car extends Auditable<String> implements Serializable {
    private static final long serialVersionUID = 2877879787472382732L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String model;
    private String manufacturer;
    private String region;
    private int price;
    private String year;
    private String fuel;
    private String transmission;
    private String type;
    private String paint_color;
    private String description;
    private String posting_date;

}
