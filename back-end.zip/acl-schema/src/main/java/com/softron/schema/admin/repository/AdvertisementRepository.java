package com.softron.schema.admin.repository;

import com.softron.schema.admin.entity.Advertisement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AdvertisementRepository extends JpaRepository<Advertisement, Long> {

    Advertisement findByIdAndIsActiveTrue(Long id);
}
