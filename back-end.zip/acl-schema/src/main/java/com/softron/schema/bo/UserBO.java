package com.softron.schema.bo;

public interface UserBO {

    String getUserName();

    String getFullName();

    String getEmail();

}
