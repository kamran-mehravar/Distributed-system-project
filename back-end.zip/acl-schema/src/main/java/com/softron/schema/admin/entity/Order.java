package com.softron.schema.admin.entity;

import com.softron.datastore.Auditable;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "ORDERS")
@Data
public class Order extends Auditable<String> implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = 4865992894467088117L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;

    private String title;

    @Temporal(TemporalType.TIMESTAMP)
    private Date orderDate;

    private String status;

    private Boolean isActive;

}

