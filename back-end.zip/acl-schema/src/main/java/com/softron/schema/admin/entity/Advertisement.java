package com.softron.schema.admin.entity;

import com.softron.datastore.Auditable;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "ADVERTISEMENT")
@Data
public class Advertisement extends Auditable<String> implements Serializable {
    private static final long serialVersionUID = 2877879787472382732L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String description;
    private double price;
    private String region;
    private String manufacturer;
    private int productionYear;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private UserEntity user;

    @Column(name = "ACTIVE", nullable = false)
    private Boolean isActive;

}
