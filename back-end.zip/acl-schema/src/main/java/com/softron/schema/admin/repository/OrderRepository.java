package com.softron.schema.admin.repository;

import com.softron.schema.admin.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

    Order findByIdAndIsActiveTrue(Long id);
}
