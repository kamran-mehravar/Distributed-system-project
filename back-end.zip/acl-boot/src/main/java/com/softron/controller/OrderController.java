package com.softron.controller;

import com.softron.admin.dto.OrderDto;
import com.softron.admin.service.OrderService;
import com.softron.common.businessobjects.Response;
import com.softron.common.utils.UrlConstants;
import com.softron.core.annotations.ApiController;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@ApiController
@RequestMapping(UrlConstants.OrderManagement.ROOT + UrlConstants.OrderManagement.GET_ALL)
public class OrderController {

    private final OrderService orderService;
    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @PostMapping
    public Response create(@RequestBody OrderDto orderDto, HttpServletRequest request, HttpServletResponse response) {
        return orderService.create(orderDto);
    }

    @GetMapping
    public Response getAll(HttpServletRequest request, HttpServletResponse response, Pageable pageable,
                           @RequestParam(value = "export", defaultValue = "false") boolean isExport,
                           @RequestParam(value = "search", defaultValue = "") String search,
                           @RequestParam(value = "status", defaultValue = "") String status) {
        return orderService.getAll(pageable, isExport, search, status);
    }


}
