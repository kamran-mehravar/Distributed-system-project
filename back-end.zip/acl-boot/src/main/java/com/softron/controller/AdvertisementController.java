package com.softron.controller;

import com.softron.admin.dto.AdvertisementDto;
import com.softron.admin.erlang.dto.AdvertisementExternalDto;
import com.softron.admin.service.AdvertisementService;
import com.softron.common.businessobjects.Response;
import com.softron.common.utils.UrlConstants;
import com.softron.core.annotations.ApiController;
import com.softron.security.domain.UserPrincipal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.security.Principal;

@ApiController
@RequestMapping(UrlConstants.AdvertisementManagement.ROOT + UrlConstants.AdvertisementManagement.GET_ALL)
public class AdvertisementController {

    private final AdvertisementService advertisementService;
    private final UserDetailsService userDetailsService;
    public AdvertisementController(AdvertisementService advertisementService,
                                   UserDetailsService userDetailsService) {
        this.advertisementService = advertisementService;
        this.userDetailsService = userDetailsService;
    }

    @PostMapping
    public Response create(@RequestBody AdvertisementExternalDto advertisementDto, final Principal principal) {
        final UserPrincipal user = (UserPrincipal) userDetailsService.loadUserByUsername(principal.getName());

        return advertisementService.create(advertisementDto);
    }

    @GetMapping
    public Response getAll(HttpServletRequest request, HttpServletResponse response, Pageable pageable,
                           @RequestParam(value = "export", defaultValue = "false") boolean isExport,
                           @RequestParam(value = "search", defaultValue = "") String search,
                           @RequestParam(value = "status", defaultValue = "") String status) {
        return advertisementService.getAll(pageable, isExport, search, status);
    }

    @GetMapping(UrlConstants.AdvertisementManagement.GET)
    public Response get(@PathVariable(value = "id") Long id, HttpServletRequest request, HttpServletResponse response) {
        return advertisementService.get(id);
    }

    @DeleteMapping(UrlConstants.AdvertisementManagement.GET)
    public Response delete(@PathVariable(value = "id") String id) {
        return advertisementService.delete(id);
    }

    @PutMapping(UrlConstants.AdvertisementManagement.GET)
    public Response update(@PathVariable(value = "id") String id, @RequestBody AdvertisementExternalDto advertisementDto) {
        return advertisementService.update(id, advertisementDto);
    }


}
