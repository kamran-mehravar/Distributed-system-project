package com.softron.controller;

import com.softron.admin.service.CarService;
import com.softron.common.businessobjects.Response;
import com.softron.common.utils.UrlConstants;
import com.softron.core.annotations.ApiController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@ApiController
@RequestMapping(UrlConstants.CarManagement.ROOT + UrlConstants.CarManagement.GET_ALL)
public class CarController {

    private final CarService carService;
    public CarController(CarService carService) {
        this.carService = carService;
    }

    @GetMapping(UrlConstants.CarManagement.GET_COUNT)
    public Response count(HttpServletRequest request, HttpServletResponse response) {
        return carService.count();
    }

    @GetMapping
    public Response getAll() {
        return carService.getAll();
    }
}
