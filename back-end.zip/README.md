Second-hand Car Advertisement application Based on Erlang distributed server
