package com.softron.common.transferobjects;

import java.util.ArrayList;
import java.util.List;

public class TreeTO {

    private Long id;

    private Long parentId;

    private Long parent;

    private String parentName;

    private String name;
    
    private String rootPath;

    private List<TreeTO> children = new ArrayList<>();

    public TreeTO(Long id, Long parentId, Long parent, String parentName, String name, String rootPath) {
        this.id = id;
        this.parentId = parentId;
        this.parent= parent;
        this.parentName = parentName;
        this.name = name;
        this.rootPath = rootPath;
    }

    public TreeTO(Long id, Long parentId, Long parent, String parentName,  String name, String rootPath, TreeTO child) {
        this.id = id;
        this.parentId = parentId;
        this.parent= parent;
        this.parentName = parentName;
        this.name = name;
        this.rootPath = rootPath;
        this.children.add(child);
    }

    public TreeTO(Long id, Long parentId, Long parent, String parentName,  String name, String rootPath, List<TreeTO> children) {
        this.id = id;
        this.parentId = parentId;
        this.parent= parent;
        this.parentName = parentName;
        this.name = name;
        this.rootPath = rootPath;
        this.children = children;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public Long getParent() {     return parent;    }

    public void setParent(Long parent) {        this.parent = parent;    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRootPath() {
		return rootPath;
	}

	public void setRootPath(String rootPath) {
		this.rootPath = rootPath;
	}

	public List<TreeTO> getChildren() {
        return children;
    }

    public void setChildren(List<TreeTO> children) {
        this.children = children;
    }

    public void addChildren(List<TreeTO> children) {
        this.children.addAll(children);
    }

    public void addChild(TreeTO child) {
        this.children.add(child);
    }

}
