package com.softron.common.utils;

public final class UrlConstants {
	private UrlConstants(){
		
	}
    
	private static final String API = "/api";
	private static final String VERSION = "/v1";

	public static class Client{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/clients";
		public static final String GET_CLIENTSTIME = "/clientsTime";
		public static final String GET_CLIENTDASHBOARD =GET_ALL+"/getClientDashBoard";
		public static final String GET_CLIENTCHART =GET_ALL+"/getClientChart";
		public static final String GET = GET_ALL + "/{id}";
	}

	public static class Company{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/companies";
		public static final String GET_QUALITYTREE = GET_ALL+"/getQualityTree";
		public static final String GET = GET_ALL + "/{id}";
	}
	public static class Customer{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/customers";
		public static final String GETCUSBYNAME = GET_ALL +"/getCustomerByName";
		public static final String GET = GET_ALL + "/{id}";
	}
	public static class Defect{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/defects";
		public static final String GET = GET_ALL + "/{id}";
	}
	public static class Department{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/departments";
		public static final String GET = GET_ALL + "/{id}";
	}
	public static class Employee{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/employees";
		public static final String EMPLOYEEPROFILEINFO =GET_ALL+"/getEmployeeProfileInfo";
		public static final String EMPLOYEEPROFILECHART =GET_ALL+"/getEmployeeProfileChart";
		public static final String EMPLOYEE_REPORT =GET_ALL+"/getEmployeeReport"+"/{formate}";
		public static final String GET = GET_ALL + "/{id}";
		public static final String GET_ALL_CO_WORKER_CS = "/coWorkerCS";
		public static final String EMPLOYEE_CREATE_FROM_EXCEL =GET_ALL+"/employeeCreateFromExcel";
	}
	public static class Operation{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/operations";
		public static final String GET = GET_ALL + "/{id}";
	}
	public static class Plant{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/plants";
		public static final String GET = GET_ALL + "/{id}";
	}
	public static class Section{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/sections";
		public static final String GET_SUBSECTION = GET_ALL+"/getsubsection";
		public static final String GET_SECTION = GET_ALL+"/getsection";
		public static final String GET = GET_ALL + "/{id}";
		
		public static final String GET_ORGANIZATION_SECTION = GET_ALL+"/getOrganizationWiseSection";
	}
	public static class WorkProcess{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/workProcess";
		public static final String GET = GET_ALL + "/{id}";
	}
	public static class OrderEntity{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/orderEntities";
//		public static final String GET_STYLE = GET_ALL+"/customer";
		public static final String GET_ORDER = GET_ALL+"/customer";
		public static final String GET_ORDER_LIST = GET_ALL+"/getOrderList";
		public static final String GET_ORDER_SUMMERY = GET_ALL+"/getOrderSummery";
		public static final String GET_PARAMETER_SELECTION_PANEL = GET_ALL+"/getParameterSelectionPanel";
		public static final String GET = GET_ALL + "/{id}";
	}
	public static class Style{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/styles";
		public static final String GET = GET_ALL + "/{id}";
		public static final String GET_ALL_STYLE_BY_CUSTOMER = "/getStylesByCustomer/{id}";
		public static final String GET_ALL_STYLE_BY_BUYER = "/getStylesByBuyer/{id}";
		public static final String UPDATE_ORDER_BY_EDIT = GET_ALL + "/updateOrderByEdit" + "/{id}";
		public static final String UPDATE_ORDER_BY_DRAGDROP = GET_ALL + "/updateOrderByDragDrop" + "/{id}";
	}
	public static class OperationBreakDown{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/operationBreakDowns";
		public static final String GET_OPBDBYSTYLE = GET_ALL+"/getByStyle";
		public static final String GET = GET_ALL + "/{id}";
	}
	public static class MachineType{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/machineTypes";
		public static final String GET = GET_ALL + "/{id}";
	}
	public static class QualityDefect{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/qualityDefects";
		public static final String TOPTHREEQDEFECT =GET_ALL+"/topThreeQualityDefects";
		public static final String GET = GET_ALL + "/{id}";
		public static final String GET_TOPQUALITYDEFECT =GET_ALL+"/getTopQualityDefects";
		public static final String GET_PARETO_CHART =GET_ALL+"/getParetoChart";
	}
	public static class QualityTransaction{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/qualityTransactions";
		public static final String GET_SUM = GET_ALL+"/getCheckValue";
		public static final String GET_TSL = GET_ALL+"/getTLSdashBoard";
		public static final String GET_SILHOUETTE_IMAGE = GET_ALL+"/getSilhouetteDashboardImage";
		public static final String GET_HOURLY_DEFECT_GRAPH = GET_ALL+"/getHourlyDefectGraph";
		public static final String GET_SILHOUETTE_HEADER = GET_ALL+"/getSilhouetteDashBoardHeader";
		public static final String GET_TREND = GET_ALL+"/getTrendsdashBoard";
		public static final String GET_TRENDALLSEC = GET_ALL+"/getTrendsGraphValue";
		public static final String GET_BARCHART = GET_ALL+"/getBarChartValue";
		public static final String GET_TOPFIVEQUALITYDEFECT = GET_ALL+"/getTopFiveQualityDefect";
		public static final String GET = GET_ALL + "/{id}";
		public static final String GET_QUALITYBARCHART = GET_ALL+"/getQualityBarChart";
		public static final String GET_QUALITYTRENDALLSEC = GET_ALL+"/getQualityTrendsGraph";
		public static final String GET_TOPDEFECTIVEOPERATION = GET_ALL+"/getTopDefectiveOperation";
		public static final String GET_QCPASSREPORT = GET_ALL+"/getQcPassReport";
		public static final String GET_DEFECTANALYSISREPORT = GET_ALL+"/getDefectAnalysisReport";
		public static final String GET_REPORTSHARE = GET_ALL+"/getReportShare";
		public static final String GET_LINE_WISE_ORDER_INFO = GET_ALL+"/getLineWiseOrderInfo";
		public static final String GET_END_LINE_QC = GET_ALL+"/getEndLineQc";
	}
	public static class QualityTransactionDraft{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/qualityTransactionsDraft";
	}
	public static class QualityType{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/qualityTypes";
		public static final String GET = GET_ALL + "/{id}";
	}
	public static class OperationMachine{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/operationMachine";
		public static final String GET_ALL_OPMC = "/getAllOperationMachine";
		public static final String DELETE_BY_LIST = GET_ALL+"/deleteByIdList";
		public static final String GET = GET_ALL + "/{id}";
	}
	public static class Production{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/productions";
		public static final String P_BAR_CHART = GET_ALL+"/getProductionBarChart";
		public static final String P_DASHBOARD = GET_ALL+"/ProductionDashBoard";
		public static final String P_HOURLY_GRAPH =GET_ALL+"/getProductionHourlyGraph";
		public static final String GET = GET_ALL + "/{id}";
		public static final String GET_PRODUCTIONREPORT = GET_ALL + "/getProductionReport";
		public static final String GET_PRODUCTION_REPORT_QC_PASS = GET_ALL + "/getProductionReportQcPass";
		public static final String P_DASHBOARD_QC_PASS = GET_ALL+"/ProductionDashBoardQcPass";
		public static final String LINE_WISE_PRODUCTION_CHART = GET_ALL+"/getLineWiseProductionChart";
		public static final String LINE_WISE_HOURLY_PRODUCTION_CHART = GET_ALL+"/getLineWiseHourlyProductionChart";
		public static final String OPERATION_ANALYSIS_COUTER_DEVICE = GET_ALL+"/getOperationAnalysisCd";
		public static final String EMPLOYEE_PERFORMED_PROCESS_LIST = GET_ALL+"/getEmployeePerformedProcessList";
		public static final String EMPLOYEE_PROCESS_WISE_CYCLE_TIME_TREND = GET_ALL+"/getEmployeeProcessWiseCycleTimeTrend";
		public static final String HOURLY_PRODUCTION_AND_DHU_MONITORING_BOARD = GET_ALL+"/getHourlyProductionAndDhuMonitoringBoard";
		public static final String PRODUCTION_DETAILS_REPORT = GET_ALL+"/getProductionDetailsReport";
		public static final String PRODUCTION_DETAILS_GRAPH_REPORT = GET_ALL+"/getProductionDetailsGraphReport";
		public static final String PRODUCTION_BY_DATE = GET_ALL+"/getProductionByDate";
		public static final String EFFICIENCY_MONTH = GET_ALL+"/getEfficiencyByMonth";
		public static final String EFFICIENCY_YEAR = GET_ALL+"/getEfficiencyByYear";
		public static final String PRODUCTIVITY_EFFICIENCY = GET_ALL+"/getProductivityEfficiency";
		public static final String GET_TODAYS_HOUR_WISE_PRODUCTION_BAR = GET_ALL+"/getTodaysHourWiseProductionBar";
		public static final String GET_TODAYS_HOUR_WISE_PRODUCTION__EFFICIENCY_BAR = GET_ALL+"/getTodaysHourWiseProductionEfficiencyBar";
		public static final String GET_TODAYS_QC_REPORT = GET_ALL+"/getTodaysQcReport";
		public static final String GET_TODAYS_TOP_FIVE_QUALITY_DEFECT = GET_ALL+"/getTodaysTopFiveQualityDefects";
	}
	
	public static class ProductionLight{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/productionLights";
		public static final String GET = GET_ALL + "/{id}";
		
	}
	
	public static class Varience{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/varience";
		public static final String GET_COLOR_BY_ORDER =GET_ALL+"/coloeListByOrder";
		public static final String GET_Varience_BY_ORDER_AND_COLOR =GET_ALL+"/varienceListByOrderAndColor";
		public static final String GET = GET_ALL + "/{ids}";
	}
	public static class TargetAndManpower {
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/targetAndManpower";
		public static final String HOUR_WISE_CREATE =GET_ALL+"/hrWiseCreateApi";
		public static final String HOUR_WISE_UPDATE =GET_ALL+"/hrWiseUpdateApi"+"/{id}";
		public static final String GET_All_BETWEEN_TWO_DATE =GET_ALL+"/getTargetAndManpowerByStartDateAndEndDate";
		public static final String GET = GET_ALL + "/{id}";
	}
	public static class ReportLayout{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/reportLayout";
		public static final String GET = GET_ALL + "/{id}";
		public static final String GET_BY_TYPE = GET_ALL+"/getByType";
	}

	public static class CapacityStudy{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/capacityStudy";
		//public static final String GET = GET_ALL+"/update";
		public static final String GET_CAPACITY_GRAPH_DATA = GET_ALL+"/getGraphData"+"/{capacityId}";
		public static final String GET_CAPACITY_REPORT_DATA = GET_ALL+"/getReportData"+"/{capacityId}";
		public static final String GET_EMPLOYEE_PROFILE = GET_ALL+"/getEmployeeProfileFromCapacityStudy"+"/{employeeId}";
		public static final String GET_OPERATION_ANALYSIS_CS = GET_ALL+"/getOperationAnalysisCS";
		public static final String GET_CS_BY_STATUS_IS_COMPLETE = GET_ALL+"/getAllByStatusIsComplete";
		public static final String GET_CS_BY_STATUS_IS_PARTIAL = GET_ALL+"/getAllByStatusIsPartial";
		public static final String GET_RESUMELIST = GET_ALL+"/getResumeList";
		public static final String GET_OPERATION_ANALYSIS_TREND = GET_ALL+"/getOperatorCycleTimeTrends";
		public static final String WORK_STUDY_CAPACITY_GRAPH = GET_ALL+"/getCapacityStudyGraph";
		public static final String WORK_STUDY_CAPACITY_GRAPH_2 = GET_ALL+"/getCapacityStudyGraph2";
		public static final String GET_INCOMPLETE_CS_LIST = GET_ALL+"/getIncompleteCsList";
		public static final String GET_NEWS_FEED = GET_ALL+"/getNewsFeed";
		public static final String GET_NEWS_FEED_HEADER_INFO = GET_ALL+"/getNewsFeedHeaderInfo";
	}
	
	public static class Home {
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/home";
		public static final String GET_THIS_YEAR_PRODUCTION_BAR = GET_ALL+"/productionBar";
		public static final String GET_THIS_MONTH_PROGRESS = GET_ALL+"/thismonthprogress";
		public static final String GET_BUYER_WISE_PRODUCTION = GET_ALL+"/buyerWiseProductionByDate";
		public static final String GET_EFFICIENCY_BY_DATE = GET_ALL+"/getEfficiencyByDate";
		public static final String GET_DHU_BY_DATE = GET_ALL+"/getDhuByDate";
		
	}
	
	public static class Device{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/device";
		public static final String GET = GET_ALL + "/{id}";
	}
	
	public static class Machine{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/machine";
		public static final String GET = GET_ALL + "/{id}";
	}
	
	public static class Item {
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/items";
		public static final String GET = GET_ALL + "/{id}";
		public static final String UPLOAD = GET_ALL +"/upload"+ "/{id}";
		public static final String GET_OPERATION_BREAK_DOWN = GET_ALL + "/getOperationBreakDown/{id}";
		public static final String ITEM_WISE_OPERATION_BREAK_DOWN = GET_ALL + "/getItemOperationBreakDown/{id}";

	}
	
	public static class LeadTimeSettings {
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/leadTimeSettings";
		public static final String GET = GET_ALL + "/{id}";
		public static final String GET_TIME = GET_ALL+"/getTime";

	}

	public static class AlarmTimeSettings {
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/alarmTimeSettings";
		public static final String GET = GET_ALL + "/{id}";
	}
	public static class AdvertisementManagement {
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/advertisements";
		public static final String GET = "/{id}";
	}

	public static class Erlang {
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/erlang";
		public static final String GET = "/{id}";
	}

	public static class OrderManagement {
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/orders";
		public static final String GET = "/{id}";
	}

	public static class CarManagement {
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/cars";
		public static final String GET = "/{id}";
		public static final String GET_COUNT = "/count";
	}
	public static class KanbanWorkFlow {
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/kanbanWorkFlow";
		public static final String GET = GET_ALL + "/{id}";
		public static final String GET_BY_BOARD = GET_ALL + "/kanbanBoard" + "/{id}";
		public static final String GET_WIP_UPDATE = GET_ALL + "/wipUpdate/{id}";
	}
	
	public static class KanbanBoards {
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/kanbanBoard";
		public static final String GET = GET_ALL + "/{id}";
	}
	
	public static class KanbanCard {
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/kanbanCard";
		public static final String GET = GET_ALL + "/{id}";
		public static final String GET_BY_BOARD = GET_ALL + "/kanbanBoard" + "/{id}";
	}

	public static class KanbanSlip {
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/kanbanSlip";
		public static final String GET_ALL_BY_STATUS =GET_ALL+ "/kanbanSlipStatus";
		public static final String GET_ALL_BY_DATE = "/kanbanSlip"+"/getAllByStartAndEndDate";
		public static final String GET = GET_ALL + "/{id}";
		public static final String GET_BY_BOARD = GET_ALL + "/kanbanSlipBoard";
		public static final String GET_REQUIRE_INPUT = GET_ALL + "/requireInput";
	}

	public static class CoreApprovalAuthority{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/approvalAuthority";
		public static final String GET = GET_ALL + "/{id}";
		public static final String ORG_USER_LIST_GET_ALL = "/orgUserList";
	}

	public static class CoreApprovalMatrix{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/approvalMatrix";
		public static final String GET = GET_ALL + "/{id}";
	}

	public static class CoreApprovingProcess{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/approvingProcess";
		public static final String GET = GET_ALL + "/{id}";
	}

	public static class Notification {
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/notification";
		public static final String GET = GET_ALL + "/{id}";
		public static final String GET_BY_STATUS = GET_ALL+"/status";
		public static final String MAKE_SEEN = GET_ALL+"/makeSeen";



	}
	public static class KanbanTaskURL {
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/kanbanTask";
		public static final String GET = GET_ALL + "/{id}";
		public static final String GET_BY_CARD = GET_ALL + "/kanbanCard" + "/{id}";
	}
	
	public static class ItemWiseOperationBreakDown {
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/ItemWiseOperationBreakDown";
		public static final String GET = GET_ALL + "/{id}";
	}
	
	public static class LineWiseStyleInfo{
		public static final String ROOT = API + VERSION;
		public static final String GET_ALL = "/lineWiseStyleInfo";
		public static final String GET = GET_ALL + "/{id}";
	}

}