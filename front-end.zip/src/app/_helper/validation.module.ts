import { NgModule } from '@angular/core';
import { TelephoneNumberFormatValidatorDirective } from './telephone.validator';


@NgModule({
    declarations: [TelephoneNumberFormatValidatorDirective],
})
export class ValidationModule { }
