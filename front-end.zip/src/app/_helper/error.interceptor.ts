import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { NbAuthService } from '@nebular/auth';

import { ToastService } from '../@core/service/toast.service';
import { DialogService } from '../@core/service';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {

    constructor(
        private authService: NbAuthService,
        private toaster: ToastService,
        private dialog: DialogService) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(request).pipe(catchError(err => {
            if (err.status === 401) {
                // auto logout if 401 response returned from api
                this.authService.logout('email');
                location.reload(true);
            }
            if (err.status === 500) {
                this.toaster.error({ title: 'Error', message: err.error.message });
            }

            if (err.status === 400) {
                if (err.error) {
                    this.processValidationErrors(err.error);
                } else {
                    this.processValidationErrors(err);
                    // this.toaster.error({ title: 'Invalid data', message: err.error.errors.join('\n') });
                }
            }

            const error = err.error.message || err.statusText;
            return throwError(error);
        }));
    }

    processValidationErrors(errors: any) {
        let msg = '';
        for (const key in errors) {
            if (errors.hasOwnProperty(key)) {
                msg += key + ': ' + errors[key] + '\n\n\n';
            }
        }
        this.dialog.open('Validation Error', msg);
    }
}
