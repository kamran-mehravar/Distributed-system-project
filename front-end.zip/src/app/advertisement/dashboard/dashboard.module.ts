import { NgModule } from '@angular/core';

import { ThemeModule } from '../../@theme/theme.module';
import { DashboardComponent } from './dashboard.component';
import { TranslateModule } from '@ngx-translate/core';

@NgModule({
    imports: [
        ThemeModule,
        TranslateModule,
    ],
    declarations: [
        DashboardComponent,
    ],
})
export class DashboardModule { }
