import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import {FormSubmitEvent} from '../../@common';
import {ToastService} from '../../@core/service';
import {AdvertisementService} from '../advertisement.service';
import {Advertisement} from '../advertisement';
import {User} from '../../pages/user/user';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'ngx-create-advertisement',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.scss']
})


export class CreateComponent implements OnInit {
  @ViewChild('advertisementForm') advertisementForm: NgForm;

  advertisement: Advertisement;

  opts: any = {
    idField: 'id',
    useCheckbox: false,
  };
  users: User[] = [
    {userName: 'admin',
      fullName: 'Admin', editing: null, email: null, govtId: null, mobile: null,
      moduleIds: null, orgId: null, rolesIds: null, roles: null, password: null},
  ];

  constructor(public service: AdvertisementService, public toaster: ToastService) {
    //super(service, toaster);
    //this._reset();
  }

  ngOnInit() {
    this.reset()
  }

  reset() {
    this.advertisement = new Advertisement();
  }

  onSubmit(){
      // Extract the userName from the user object
      const userName = this.advertisement.user.userName;

      // Create a new advertisement object with only the userName field
      const newAdvertisement = {
        ...this.advertisement,
        user: { userName: userName }
      };

      this.service.saveAdvertisement(newAdvertisement).subscribe((ret: any)=>{
        if(ret.status == 'Created')
        {
          this.toaster.created();
          this.reset();
          //this.LoadData();
        }
        else
        {
          this.toaster.notCreated();
        }
      })
    }

}
