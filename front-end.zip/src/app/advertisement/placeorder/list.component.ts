import { Component } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';
import { IDModel } from '../../@core/models';
import { ToastService } from '../../@core/service/toast.service';
import {Advertisement} from '../advertisement';
import {AdvertisementService} from '../advertisement.service';
import {OrderService} from '../../order/order.service';
import {Order} from '../../order/order';

@Component({
    selector: 'ngx-location-list',
    templateUrl: './list.component.html',
    styles: [`
    nb-card {
      transform: translate3d(0, 0, 0);
    }
  `],
})
export class PlaceOrderComponent   {


    settings = {
        mode: 'inline',
        pager: {
            perPage: 10,
        },
        actions: {
            add: false,
            edit: false,
            delete: true,
        },
        add: {
            addButtonContent: '<i class="nb-edit"></i>',
            createButtonContent: '<i class="nb-checkmark"></i>',
            cancelButtonContent: '<i class="nb-close"></i>',
            confirmCreate: true,
        },
        edit: {
            editButtonContent: '<i class="nb-edit"></i>',
            saveButtonContent: '<i class="nb-checkmark"></i>',
            cancelButtonContent: '<i class="nb-close"></i>',
            confirmSave: true,
        },
        delete: {
            deleteButtonContent: '<i class="ion-document" title="Place Order"></i>',
            confirmDelete: true,
        },
        columns: {
            id: IDModel,
            title: {
                title: 'Title',
                type: 'string',
            },
            description: {
                title: 'Description',
                type: 'string',
            },
          price: {
                title: 'Price',
                type: 'number',
            },
          region: {
                title: 'Region',
                type: 'string',
            },
          manufacturer: {
                title: 'Manufacturer',
                type: 'string',
            },
          productionYear: {
                title: 'Production Year',
                type: 'number',
            },
        },
    };

  source: LocalDataSource = new LocalDataSource();

  constructor(public service: AdvertisementService, public orderService: OrderService, public toaster: ToastService) {
    this.load();
  }

  load(): void {
    this.service.getAll().subscribe((res: any) => {
      this.source.load(res.content as Advertisement[]);
    });
  }

  reloadGrid(): void {
    this.load();
  }

  onCreate(event): void {
    /*this.service.save(event.newData).subscribe(response => {
      if (response.status) {
        this.toaster.created();
        event.confirm.resolve();
        this.reloadGrid();
      } else {
        this.toaster.notCreated();
      }
    });*/
  }

  onEdit(event): void {
    this.service.updateAdvertisement(event.newData).subscribe((res: any) => {
      if (res.status) {
        this.toaster.updated();
        event.confirm.resolve();
        this.reloadGrid();
      } else {
        this.toaster.notUpdated();
      }
    });
  }

  onPlaceOrderConfirm(event: any) {
    if ( confirm('Are you sure to place this order?') === true) {
      const order = new Order();
      order.advertisement = event.data as Advertisement;
      this.orderService.saveOrder(order).subscribe((res: any) => {
        if (res.statusCode === 201) {
          this.toaster.created();
        }else {
          this.toaster.notCreated();
        }
      });
    }
  }
}
