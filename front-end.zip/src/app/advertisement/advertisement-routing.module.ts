import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';

import { AdvertisementComponent } from './advertisement.component';

import {DashboardComponent} from './dashboard/dashboard.component';
import {CreateComponent} from './create/create.component';
import {ListComponent} from './list/list.component';
import {PlaceOrderComponent} from './placeorder/list.component';


const routes: Routes = [{
  path: '',
  component: AdvertisementComponent,
  children: [
    {
      path: 'dashboard',
      component: DashboardComponent,
    },
    {
      path: 'create',
      component: CreateComponent,
    },
    {
      path: 'list',
      component: ListComponent,
    },
    {
      path: 'placeorder',
      component: PlaceOrderComponent,
    },
],
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdvertisementRoutingModule {
}

