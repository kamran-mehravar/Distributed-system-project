import { Injectable } from '@angular/core';
import {BaseService} from '../@common';
import {HttpClient} from '@angular/common/http';
import { environment as env } from '../../environments/environment';


@Injectable({
  providedIn: 'root',
})
export class AdvertisementService {

    apiURL: string;
    constructor(private http: HttpClient) {
        this.apiURL = env.apiHost + env.apiPrefix + '/v1';
    }
    saveAdvertisement(advertisement: any) {

        return this.http.post(this.apiURL + '/advertisements', advertisement);
    }
    updateAdvertisement(advertisement: any) {
        let id = advertisement.id;
        let cleanedId = id.replace(/'/g, '');
        return this.http.put(this.apiURL + '/advertisements' +`/${cleanedId}` , advertisement);
    }
    deleteAdvertisement(advertisement: any) {
        let id = advertisement.id;
        let cleanedId = id.replace(/'/g, '');
        return this.http.delete(this.apiURL + '/advertisements' +`/${cleanedId}` , advertisement);
    }
    getAll() {
        return this.http.get(this.apiURL + '/advertisements');
    }
}
