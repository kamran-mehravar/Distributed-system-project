import {User} from '../pages/user/user';

export class Advertisement {
    id: number;
    title: string;
    description: string;
    price: number;
    region: string;
    manufacturer: string;
    productionYear: number;
    user: User;
    constructor() {

    }
  }
