import { Injectable } from '@angular/core';
import {
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor,
    HttpErrorResponse,
} from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { ProfileService } from '../@core/service';
import { NbAuthService, NbAuthSimpleToken } from '@nebular/auth';
import { Router } from '@angular/router';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class HeaderInterceptor implements HttpInterceptor {

    constructor(public profile: ProfileService, private router: Router) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        const module: any = this.profile.getActiveModule();
        if (module !== null) {
            request = request.clone({
                setHeaders: {
                    'X-MOD-ID': module.id.toString(),
                },
            });
        }
        return next.handle(request);
    }

}
