import { Injectable } from '@angular/core';
import { NbAuthService, NbAuthJWTToken } from '@nebular/auth';
import { CanActivate } from '@angular/router';
import { ProfileService } from '../@core/service/profile.service';

@Injectable()
export class AdminAuthGuard implements CanActivate {


    adminRole = 'ROLE_ADMIN';
    isAdmin = false;
    contextPath = 'pages';

    constructor(private authService: NbAuthService, private profile: ProfileService) {
        this.authService.getToken().subscribe((token: NbAuthJWTToken) => {
            const roles = token.getPayload().roles;
            if (roles.indexOf(this.adminRole) > -1) {
                this.isAdmin = true;
            }
        });
    }

    canActivate() {
        return this.profile.hasModuleAccess(this.contextPath);
    }
}
