import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { ProfileService } from '../@core/service/profile.service';

@Injectable()
export class LegalAuthGuard implements CanActivate {

    contextPath = 'legal';

    constructor(private profile: ProfileService) {
    }

    canActivate() {
        return this.profile.hasModuleAccess(this.contextPath);
    }
}