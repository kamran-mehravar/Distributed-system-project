import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { ProfileService } from '../@core/service/profile.service';

@Injectable()
export class ReportingAuthGuard implements CanActivate {

    contextPath = 'reporting';

    constructor(private profile: ProfileService) {
    }

    canActivate() {
        return this.profile.hasModuleAccess(this.contextPath);
    }
}
