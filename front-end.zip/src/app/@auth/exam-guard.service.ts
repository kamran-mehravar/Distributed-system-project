import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { ProfileService } from '../@core/service/profile.service';

@Injectable()
export class ExamAuthGuard implements CanActivate {

    contextPath = 'exam';

    constructor(private profile: ProfileService) {
    }

    canActivate() {
        return this.profile.hasModuleAccess(this.contextPath);
    }
}