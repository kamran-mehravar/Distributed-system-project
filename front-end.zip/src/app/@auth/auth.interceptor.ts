import { Injectable } from '@angular/core';
import {
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor,
} from '@angular/common/http';
import { NbAuthService } from '@nebular/auth';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';

import { ToastService } from '../@core/service/toast.service';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

    constructor(public authService: NbAuthService, private router: Router, private toaster: ToastService) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        const string = request.url;
        const result = string.match(/(public|en.json)/g);
        const isAuth = string.match(/auth/g);
        if (!result && !isAuth) {
            this.authService.getToken().subscribe((token => {
                if (token.isValid()) {
                    request = request.clone({
                        setHeaders: {
                            Authorization: 'Bearer ' + token.getValue(),
                        },
                    });
                } else {
                    this.router.navigateByUrl('/auth/login');
                }
            }));
        }
        return next.handle(request);
    }
}
