/**
 * @license
 * Copyright Akveo. All Rights Reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 */
import { Component, OnInit, OnDestroy } from '@angular/core';
import { AnalyticsService } from './@core/utils/analytics.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
    selector: 'ngx-app',
    template: '<router-outlet></router-outlet>',
})
export class AppComponent implements OnInit, OnDestroy {

    constructor(private analytics: AnalyticsService, private translate: TranslateService) {
        this.translate.addLangs(['en', 'bn']);
        this.translate.setDefaultLang('en');
    }

    ngOnInit(): void {
        this.analytics.trackPageViews();
    }

    ngOnDestroy(): void {
        const remb = sessionStorage.getItem('rememberMe');
        if (!remb) {
            localStorage.clear();
        }
    }
}
