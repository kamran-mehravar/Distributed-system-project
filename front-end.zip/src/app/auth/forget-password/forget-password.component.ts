import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'ngx-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.scss'],
})
export class ForgetPasswordComponent implements OnInit {

  showMessages: any = {};
  messages: any = [];
  errors: any = [];
  resetBtn: any = { reset: 'Reset Password', inprocess: 'Processing..', resend: 'Resend email' };
  resetBtnTxt: string;

  submitted?: boolean;
  userName: string;

  constructor(public authService: AuthService, public router: Router) { }

  ngOnInit() {
    this.resetBtnTxt = this.resetBtn.reset;
  }

  requestPassword() {
    this.showMessages = {};
    this.submitted = true;
    this.resetBtnTxt = this.resetBtn.inprocess;
    this.authService.forgotPass(this.userName).subscribe((resp: any) => {
      if (resp.success) {
        this.showMessages.success = true;
        this.messages = resp.messages;
        this.resetBtnTxt = this.resetBtn.resend;
      } else {
        this.showMessages.error = true;
        this.errors = resp.messages;
        this.resetBtnTxt = this.resetBtn.reset;
      }
      this.submitted = false;
    });
    return false;
  }

}
