import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AuthRoutingModule } from './auth-routing.module';
import { NbAuthModule } from '@nebular/auth';
import {
    NbAlertModule, NbButtonModule, NbCheckboxModule, NbInputModule,
    NbLayoutModule, NbCardModule,
} from '@nebular/theme';

import { LoginComponent } from './login/login.component';
import { AuthComponent } from './auth.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        NbAlertModule,
        NbInputModule,
        NbButtonModule,
        NbCheckboxModule,
        AuthRoutingModule,
        NbAuthModule,
        NbLayoutModule,
        NbCardModule,
    ],
    declarations: [
        AuthComponent,
        LoginComponent,
        ForgetPasswordComponent,
        ResetPasswordComponent,
    ],
})
export class AuthModule {
}
