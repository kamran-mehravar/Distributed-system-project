import { Component, AfterViewInit, ViewChild } from '@angular/core';
import { NbLoginComponent } from '@nebular/auth';

@Component({
    selector: 'ngx-auth-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss'],
})
export class LoginComponent extends NbLoginComponent implements AfterViewInit {

    context: CanvasRenderingContext2D;
    isFliped = false;

    // @ViewChild('captchaCanvas') captchaCanvas: any;

    output: number;
    captchaCode: string = '';
    userInput: string;
    invalidCaptcha?: boolean = false;

    ngAfterViewInit(): void {
        // const canvas = this.captchaCanvas.nativeElement;
        // this.context = canvas.getContext('2d');
        setTimeout(() => { this.init(); });
    }

    toggleFliped() {
        this.isFliped = !this.isFliped;
    }

    validateCaptcha() {
        sessionStorage.setItem('rememberMe', this.user.rememberMe);
        this.login();
        // if (parseInt(this.userInput, 0) === this.output) {
        // } else {
        //     this.invalidCaptcha = true;
        // }
    }

    init() {
        const remb = sessionStorage.getItem('rememberMe');
        if (remb && remb !== 'undefined') {
            this.user.rememberMe = remb;
        } else {
            this.user.rememberMe = false;
        }
        this.createCaptcha();
    }


    createCaptcha() {
        const charsArray = '0123456789';
        const operationArray = ['+', '*'];

        const captcha = [];

        const num1 = Math.floor(Math.random() * charsArray.length + 1);
        const num2 = Math.floor(Math.random() * charsArray.length + 1);
        const operation = operationArray[Math.floor(Math.random() * operationArray.length)];

        if (num1 >= num2) {
            captcha.push(num1);
            captcha.push(operation);
            captcha.push(num2);
        } else {
            captcha.push(num2);
            captcha.push(operation);
            captcha.push(num1);
        }

        // this.captchaCode = captcha.join('');
        this.output = this.funcoperation(parseInt(captcha[0], 0), parseInt(captcha[2], 0), captcha[1]);

        const ctx = this.context;

        const background = new Image();
        // background.src = 'assets/images/captcha.png';

        // Make sure the image is loaded first otherwise nothing will draw.
        background.onload = function () {
            ctx.drawImage(background, 0, 0);
            ctx.font = '40px Georgia';
            ctx.fillStyle = '#989797';
            ctx.fillText(captcha.join(''), 65, 50);
        };
    }

    funcoperation(x: number, y: number, z: any) {
        switch (z) {
            case '+':
                return x + y;
            case '-':
                return x - y;
            case '*':
                return x * y;

        }
    }
    onInputChange(event: string) {
        if (event === '') {
            this.invalidCaptcha = false;
        } else {
            this.invalidCaptcha = parseInt(event, 0) !== this.output;
        }
    }
}
