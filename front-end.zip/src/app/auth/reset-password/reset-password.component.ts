import { Component, OnInit } from '@angular/core';
import { ResetPassword } from './resetpass.model';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { templateJitUrl } from '@angular/compiler';

@Component({
  selector: 'ngx-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss'],
})
export class ResetPasswordComponent implements OnInit {

  showMessages: any = {};
  messages: any = [];
  errors: any = [];

  redirectDelay: number = 0;
  strategy: string = '';

  submitted?: boolean;
  userName: string;

  tokenExpired: boolean;

  rp: ResetPassword;

  constructor(private activatedRoute: ActivatedRoute,
    private router: Router, private authService: AuthService) {
    this.rp = new ResetPassword();
  }

  ngOnInit() {
    this.activatedRoute.queryParams.subscribe(params => {
      const userId = params['id'];
      const token = params['token'];
      this.validateToken(userId, token);
    });
  }

  validateToken(userId: string, token: string) {
    this.authService.validateToken(userId, token).subscribe((resp: any) => {
      if (!resp.success) {
        this.tokenExpired = true;
        this.showMessages.error = true;
        this.errors.push('Your password reset URL has been expired. Please try to reset your password again.');
      } else {
        this.rp.username = userId;
        this.rp.token = token;
      }
    });
  }

  resetPassword() {
    // this.submitted = true
    this.authService.resetPass(this.rp).subscribe((resp: any) => {
      if (resp.success) {
        this.showMessages.success = true;
        this.messages.push('Password reset successfully.\r Please login with your new password.');
        setTimeout(() => { this.router.navigateByUrl('/auth/login'); }, 5000);
      } else {
        this.showMessages.error = true;
        this.errors = resp.messages;
        this.submitted = false;
      }
    });
  }

}
