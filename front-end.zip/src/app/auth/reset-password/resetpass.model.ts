export class ResetPassword {
    password: string;
    verifyPassword: string;
    token: string;
    username: string;
}
