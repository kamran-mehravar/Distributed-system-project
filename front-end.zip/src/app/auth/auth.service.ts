import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { environment as env } from './../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AuthService {

  apiURL: string;

  constructor(public http: HttpClient) {
    this.apiURL = env.apiHost + '/auth';
  }

  forgotPass(username: any) {
    return this.http.post(this.apiURL + '/password/forgot/' + username, null);
  }

  validateToken(username: any, token: any) {
    return this.http.post(this.apiURL + '/password/validate-token?id=' + username + '&token=' + token, null);
  }

  resetPass(resetPass: any) {
    return this.http.post(this.apiURL + '/password/reset', resetPass);
  }

}
