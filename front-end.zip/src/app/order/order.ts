
import {Advertisement} from '../advertisement/advertisement';

export class Order {
  id: number;
  advertisement: Advertisement;
  title: string;
  username: string;
  status: string;
  orderDate: any;


  constructor() {

  }
}
