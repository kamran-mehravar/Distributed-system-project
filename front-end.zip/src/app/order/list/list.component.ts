import {Component} from '@angular/core';
import {LocalDataSource} from 'ng2-smart-table';
import {DatePipe} from '@angular/common';
import {IDModel} from '../../@core/models';
import {OrderService} from '../order.service';
import {ToastService} from '../../@core/service';
import {Order} from '../order';

@Component({
  selector: 'ngx-location-list',
  templateUrl: './list.component.html',
  styles: [`
    nb-card {
      transform: translate3d(0, 0, 0);
    }
  `],
})
export class ListComponent {


  settings = {
    mode: 'inline',
    pager: {
      perPage: 10,
    },
    actions: {
      add: false,
      edit: false,
      delete: false,
    },
    add: {
      addButtonContent: '<i class="nb-plus"></i>',
      createButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmCreate: true,
    },
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmSave: true,
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    columns: {
      id: IDModel,
      title: {
        title: 'Ad. Title',
        type: 'string'
      },
      orderDate: {
        title: 'Order Date',
        type: 'any',
      },
      username: {
        title: 'User',
        type: 'string',
      },
      status: {
        title: 'Status',
        type: 'string',
      },
    },
  };

  source: LocalDataSource = new LocalDataSource();

  constructor(public service: OrderService, public toaster: ToastService) {
    this.load();
  }

  load(): void {
    this.service.getAll().subscribe((res: any) => {
      const orders: Order[] = [];
      res.content.forEach(data => {
        data.orderDate = new DatePipe('en-US').transform(data.orderDate, 'dd-MMM-yyyy');
        orders.push(data);
      });
      this.source.load(orders);
    });
  }

  reloadGrid(): void {
    this.load();
  }

  onCreate(event): void {
    /*this.service.save(event.newData).subscribe(response => {
      if (response.status) {
        this.toaster.created();
        event.confirm.resolve();
        this.reloadGrid();
      } else {
        this.toaster.notCreated();
      }
    });*/
  }

  onEdit(event): void {
    /*this.service.update(event.newData).subscribe(response => {
      if (response.status) {
        this.toaster.updated();
        event.confirm.resolve();
        this.reloadGrid();
      } else {
        this.toaster.notUpdated();
      }
    });*/
  }

  onDeleteConfirm($event: any) {
  }
}
