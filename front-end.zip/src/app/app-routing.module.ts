import {ExtraOptions, RouterModule, Routes} from '@angular/router';
import {NgModule} from '@angular/core';
import {
  AuthGuard, AdminAuthGuard, OrgManagementAuthGuard,
} from './@auth';

const routes: Routes = [
  {
    path: 'home',
    canActivate: [AuthGuard],
    loadChildren: './@home/home.module#HomeModule',
  },
  {
    path: 'pages',
    // canActivate: [AuthGuard, AdminAuthGuard],
    loadChildren: './pages/pages.module#PagesModule',
  },
  {
    path: 'advertisement',
    // canActivate: [AuthGuard, MasterDataAuthGuard],
    loadChildren: './advertisement/advertisement.module#AdvertisementModule',

  },
  {
    path: 'car',
    // canActivate: [AuthGuard, MasterDataAuthGuard],
    loadChildren: './car/car.module#CarModule',

  },
  {
    path: 'order',
    // canActivate: [AuthGuard, MasterDataAuthGuard],
    loadChildren: './order/order.module#OrderModule',

  },
  {
    path: 'auth',
    loadChildren: './auth/authentication.module#AuthModule',
  },
  {path: '', redirectTo: 'home', pathMatch: 'full'},
  {path: '**', redirectTo: 'home'},
];

const config: ExtraOptions = {
  useHash: true,
};

@NgModule({
  imports: [
    RouterModule.forRoot(routes, config),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {
}
