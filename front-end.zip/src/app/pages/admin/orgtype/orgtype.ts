export interface OrgType {
    id: number;
    name: string;
    active: boolean;
    remarks: string;
}
