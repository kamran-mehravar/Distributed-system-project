import { Component, OnInit, ViewChild } from '@angular/core';
import { Role } from '../role';
import { RoleService } from '../role.service';
import { ModuleService } from '../../module/module.service';
import { Module } from '../../module/module';
import { MenuService } from '../../menu/menu.service';
import { FormSubmitEvent } from '../../../@common/form-submit.event';
import { ToastService } from '../../../@core/service/toast.service';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { TreeComponent, ITreeOptions } from 'angular-tree-component';
import { DialogService } from '../../../@core/service';
import {ProfileService} from '../../../@core/service';

@Component({
    selector: 'ngx-users-create',
    styleUrls: ['./create.component.scss'],
    templateUrl: './create.component.html',
})
export class RoleCreateComponent extends FormSubmitEvent implements OnInit {

    role: Role;
    modules: any;
    menus: any;
    selectedMenuIds: any[];
    preSelModule: any;
    expandTree: boolean = false;

    @ViewChild('tree')
    private tree: TreeComponent;

    opts: ITreeOptions = {
        idField: 'id',
        useCheckbox: true,
        useTriState: false,
    };

    constructor(public roleService: RoleService,
        public toaster: ToastService,
        public dialog: DialogService,
        private moduleService: ModuleService,
        private menuService: MenuService,
        private router: Router,
        private route: ActivatedRoute,
        private profileService: ProfileService) {
        super(roleService, toaster);
        this.role = new Role();
        this.role.active = true;
        this.role.menuIds = null;
        this.loadModules();
    }

    ngOnInit(): void {
        this.route.paramMap.subscribe((params: ParamMap) => {
            if (params.get('id'))
                this.service.getOne(params.get('id')).subscribe((r: Role) => {
                    this.role = r;
                    this.preSelModule = r.moduleId;
                    this.loadMenuTree(r.moduleId);
                });
        });
    }

    loadModules() {
        this.menus = [];
        this.modules = [];
        this.selectedMenuIds = [];
        this.profileService.getModules().subscribe((res: Module[]) => {
            res.map(m => this.modules.push({ id: m.id, name: m.name }));
            this.role.moduleId = this.preSelModule;
        });
    }
    loadMenuTree(moduleId: number) {
        this.menuService.getTreeByModuleId(moduleId).subscribe((res) => {
            this.menus = res;
            setTimeout(() => {
                this.tree.treeModel.expandAll();
                this.setPreSelected();
            });
        });
    }
    setPreSelected() {
        if (this.role.menuIds !== null) {
            this.role.menuIds.forEach(id => {
                const node = this.tree.treeModel.getNodeById(id);
                if (node) {
                    node.setIsSelected(true);
                }
            });
        }
    }
    onModuleChange(event) {
        this.role.menuIds = null;
        this.loadMenuTree(event);
    }
    onSelect(event) {
        this.selectedMenuIds.push(event.node.data.id);
    }
    onDeselect(event) {
        this.selectedMenuIds.splice(this.selectedMenuIds.indexOf(event.node.data.id), 1);
    }
    onSubmit() {
        if (this.role.moduleId == null) {
            this.dialog.alert('Please Select Module!');
            return;
        }
        if (this.selectedMenuIds.length === 0) {
            this.dialog.alert('Please select at least one menu.');
            return;
        }
        this.role.menuIds = this.selectedMenuIds;
        super.submit(this.role);
    }
    _reset() {
        this.router.navigateByUrl('/pages/roles/list');
    }
    selectAll() {
        this._toggle(true);
    }
    deSelectAll() {
        this._toggle(false);
    }
    _toggle(val: boolean) {
        this.tree.treeModel.nodes.forEach(
            (node) => this._toggleChildren(this.tree.treeModel.getNodeById(node.id), val));
    }
    _toggleChildren(node: any, val: boolean) {
        node.setIsSelected(val);
        if (node.hasChildren) {
            node.children.forEach((child: any) => this._toggleChildren(child, val));
        }
    }
}
