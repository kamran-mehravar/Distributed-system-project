
export class Role {
    id: number;
    name: string;
    active: boolean;
    moduleId: number;
    menuIds: any[]

    constructor() { }
}
