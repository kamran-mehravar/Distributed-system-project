import { Component } from '@angular/core';

@Component({
  selector: 'ngx-location',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class LocationComponent {
}
