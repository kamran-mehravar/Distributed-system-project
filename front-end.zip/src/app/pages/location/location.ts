
export class Locations {
    id: number;
    nameEng: string;
    nameBang: string;
    abbrEng: string;
    abbrBang: string;
    keyWord: string;
    serialNo: number;
    remarks: string;
    active: boolean;
    parentId: number;

    constructor() { }

}
