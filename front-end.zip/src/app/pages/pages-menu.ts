import { NbMenuItem } from '@nebular/theme';

export const MENU_ITEMS: NbMenuItem[] = [
    {
        title: 'Dashboard',
        icon: 'ion-home',
        link: '/pages/dashboard',
        home: true,
    },
    {
        title: 'User Role',
        icon: 'nb-layout-two-column',
        children: [
            {
                title: 'Create',
                link: '/pages/roles/create',
            },
            {
                title: 'List',
                link: '/pages/roles/list',
            },
        ],
    },
    {
        title: 'Users',
        icon: 'nb-person',
        children: [
            {
                title: 'Create',
                link: '/pages/users/create',
            },
            {
                title: 'List',
                link: '/pages/users/list',
            },
        ],
    }, {
        title: 'Setup',
        icon: 'nb-gear',
        hidden: true,
        children: [
            {
                title: 'Org Type',
                link: '/pages/admin/orgtype',
            },
        ],
    },
    {
        title: 'Module',
        icon: 'nb-grid-a',
        hidden: true,
        children: [
            {
                title: 'Create',
                link: '/pages/module/create',
            },
            {
                title: 'List',
                link: '/pages/module/list',
            },
        ],
    },
    {
        title: 'Location',
        icon: 'nb-location',
        hidden: true,
        children: [
            {
                title: 'Create',
                link: '/pages/location/create',
            },
            {
                title: 'List',
                link: '/pages/location/list',
            },
        ],
    },
    {
        title: 'Organization',
        icon: 'nb-home',
        hidden: true,
        children: [
            {
                title: 'Create',
                link: '/pages/org/create',
            },
            {
                title: 'List',
                link: '/pages/org/list',
            },
        ],
    }, {
        title: 'Menu',
        icon: 'nb-menu',
        children: [
            {
                title: 'Create',
                link: '/pages/menus/create',
                hidden: true,
            },
            {
                title: 'List',
                link: '/pages/menus/list',
            },
            {
                title: 'Manage',
                link: '/pages/menus/manage',
            },
        ],
    },
];
