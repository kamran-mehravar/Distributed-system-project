import { Injectable } from '@angular/core';
import { NbAuthService, NbAuthJWTToken } from '@nebular/auth/services';
import { HttpClient } from '@angular/common/http';
import { environment as env } from '../../environments/environment';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class ProductionReportService {
  user = {};
  apiURL: string;
  orgApiURL: string;
  orgGetUrl: string

  constructor(private http: HttpClient, private authService: NbAuthService) {
    this.apiURL = env.apiHost + env.apiPrefix + '/v1';
    this.orgApiURL = env.apiHost + env.apiPrefix + '/org:loggedUserOrgtree';
    this.orgGetUrl = env.apiHost + env.apiPrefix + '/loggedUserOrg';
  }

  getCurrentDateTime(): string {
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + 'T' + time;
    return dateTime;
  }

  getCurrentFromDate(): string {
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var currentFromdate = date + 'T' + "08:00:00";
    return currentFromdate
  }

  getDynamicData(fromDate: any, todate: any, orgIds, orderIds) {
    if (orderIds == "") {
      return this.http.get(this.apiURL + '/productions/' + `getProductionReportQcPass?startDate=${fromDate}&endDate=${todate}&orgId=${orgIds}`);
    } else {
      return this.http.get(this.apiURL + '/productions/' + `getProductionReportQcPass?startDate=${fromDate}&endDate=${todate}&orgId=${orgIds}&orderEntityList=${orderIds}`);
    }

  }

  getOrgTree() {
    return this.http.get(this.orgApiURL)
  }

  formation(res: any) {
    let orgaizations = new Array()
    for (let i = 0; i < res.length; i++) {

      let plants = new Array()
      let companyObject = {
        id: res[i].id,
        text: res[i].name,
      }

      if (res[i].children.length > 0) {
        for (let j = 0; j < res[i].children.length; j++) {
          let sections = new Array()
          let plantObject = {
            id: res[i].children[j].id,
            text: res[i].children[j].name
          }
          if (res[i].children[j].children.length > 0) {
            for (let k = 0; k < res[i].children[j].children.length; k++) {
              let subSection = new Array()
              let sectionObject = {
                id: res[i].children[j].children[k].id,
                text: res[i].children[j].children[k].name
              }
              if (res[i].children[j].children[k].children.length > 0) {
                for (let l = 0; l < res[i].children[j].children[k].children.length; l++) {
                  let subSectionObject = {
                    id: res[i].children[j].children[k].children[l].id,
                    text: res[i].children[j].children[k].children[l].name
                  }
                  subSection.push(subSectionObject)

                }
              }
              sectionObject['items'] = subSection
              sections.push(sectionObject)
            }

          }
          plantObject['items'] = sections
          plants.push(plantObject)
        }

      }
      companyObject['items'] = plants
      orgaizations.push(companyObject)

    }
    return orgaizations
  }


  formation2(element: any) {

    if (element.children.length == 0) {
      let ObjectMain = {
        id: element.id,
        text: element.name,
        items: []
      }
      return ObjectMain
    }

    else {
      var Object: any = {}
      let childs = new Array()
      for (let j = 0; j < element.children.length; j++) {
        let result = this.formation2(element.children[j]);
        childs.push(result)

        if (j == (element.children.length - 1)) {
          Object.id = element.id
          Object.text = element.name
          Object.items = childs

        }

      }

    }
    return Object

  }



  searchTree(element, id) {
    if (element.id == id) {
      return element;
    } else if (element.items != null) {
      var i;
      var result = null;
      for (i = 0; result == null && i < element.items.length; i++) {
        result = this.searchTree(element.items[i], id);
      }
      return result;
    }
    return null;

  }

  getMonthNo(monthName) {

    let month
    if (monthName == 'Jan') {
      month = '01'
    } else if (monthName == 'Feb') {
      month = '02'
    } else if (monthName == 'Mar') {
      month = '03'
    }
    else if (monthName == 'Apr') {
      month = '04'
    }
    else if (monthName == 'May') {
      month = '05'
    } else if (monthName == 'Jun') {
      month = '06'
    } else if (monthName == 'Jul') {
      month = '07'
    }
    else if (monthName == 'Aug') {
      month = '08'
    }
    else if (monthName == 'Sep') {
      month = '09'
    }
    else if (monthName == 'Oct') {
      month = '10'
    }
    else if (monthName == 'Nov') {
      month = '11'
    }
    else if (monthName == 'Dec') {
      month = '12'
    }
    return month

  }

  getOrgs() {
    return this.http.get(this.orgGetUrl);
  }

  orgAndOrderFormate(org:any=0, orderIdList?) {

    let selectedOrganizationsIds = "";
    let selectedOrdersIds = ""
    if(org!=0){
      for (let i = 0; i < org.length; i++) {
        if (i == 0) {
          selectedOrganizationsIds = String(org[i].id)
        }
        else {
          selectedOrganizationsIds = String(org[i].id) + ',' + selectedOrganizationsIds
        }
      }
    }
   
    if (orderIdList) {
      for (let i = 0; i < orderIdList.length; i++) {
        if (orderIdList[i].order) {
          if (selectedOrdersIds == "") {
            selectedOrdersIds = orderIdList[i].id.split('o')[0]
          }
          else {
            selectedOrdersIds = orderIdList[i].id.split('o')[0] + ',' + selectedOrdersIds
          }
        }

      }

    }
    return { orgIdList: selectedOrganizationsIds, orderIdList: selectedOrdersIds }

  }

}
