
export class Module {
    id: number;
    name: string;
    active: boolean;
    remarks: string;
    macBindingEnabled: string;
    ipBindingEnabled: string;
    macAccessList: any[];
    ipAccessList: any[];
    constructor() {

    }
}
