import { Component } from '@angular/core';

@Component({
    selector: 'ngx-module',
    template: `
    <router-outlet></router-outlet>
  `,
})
export class ModuleComponent {

}
