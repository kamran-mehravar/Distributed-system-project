import { Component, OnInit, ViewChild } from '@angular/core';
import { User } from '../user';
import { FormSubmitEvent } from '../../../@common/form-submit.event';
import { UserService } from '../user.service';
import { OrganizationService } from '../../organization/organization.service';
import { ToastService } from '../../../@core/service/toast.service';
import { ModuleService } from '../../module/module.service';
import { Module } from '../../module/module';
import { RoleService } from '../../role/role.service';
import { Role } from '../../role/role';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import {ProfileService} from "../../../@core/service/profile.service";
import {ProductionReportService} from '../../production-report.service'



@Component({
    selector: 'ngx-users-create',
    styleUrls: ['./create.component.scss'],
    templateUrl: './create.component.html',
})
export class UserCreateComponent extends FormSubmitEvent implements OnInit {

    user: User;
    orgs: any;
    modules: any;
    roles: any;
    selectedRoles: any[];
    setSelRoles: [];
    preSelRoles: any = [];
    organizations=new Array()
    selectedorgaization:any={}
  

    @ViewChild('roleDD') roleDD: any;

    @ViewChild('modDD') modDD: any;


    opts: any = {
        idField: 'id',
        useCheckbox: true,
        useTriState: false,
    };
   

    constructor(
        public service: UserService,
        public toaster: ToastService,
        private orgService: OrganizationService,
        private moduleService: ModuleService,
        private roleService: RoleService,
        private router: Router,
        private route: ActivatedRoute,
        private profileService: ProfileService,
        private productionReportService: ProductionReportService,
     
        ) {

        super(service, toaster);
        this._reset();
    }
    loadModules() {
      this.profileService.getModules().subscribe((res: Module[]) => {
          
            res.map(m => this.modules.push({ id: m.id, name: m.name }));
        });
    }


    
    loadAllRoles() {
        this.roles = [];
        this.roleService.getAllRoles().subscribe((res: Role[]) => {
            res.map(r => this.roles.push({ id: r.id, name: r.name }));
            this.user.rolesIds = this.preSelRoles;
        });
    }
    loadRoles(moduleId: number[]) {
        this.roles = [];
        if (moduleId.length > 0) {
            this.roleService.getRolesByModule(moduleId).subscribe((res: Role[]) => {
                res.map(r => this.roles.push({ id: r.id, name: r.name }));
                this.user.rolesIds = this.preSelRoles;
            });
        }
    }
    onModuleSelect(event) {
        this.loadRoles(event);
    }
    onSubmit() {
        if (this.user.moduleIds.length === 0) {
            alert('Please Select Module.');
            return;
        }
        if (this.user.rolesIds.length === 0) {
            alert('Please Select Role.');
            return;
        }
        this.user.orgId=this.selectedorgaization.id
        console.log(this.user)
        super.submit(this.user);
    }
    _reset(): void {
        if (this.user && this.user.editing) {
            this.router.navigateByUrl('/pages/users/list');
        }
        this.user = new User();
        this.user.rolesIds = [];
        this.roles = [];
        this.modules = [];
        this.loadModules();
       
        // this.loadAllRoles();
    }

    selectOrganization(item:any){
       this.selectedorgaization.id=item.itemData.id
       this.selectedorgaization.text=item.itemData.text
    }

    ngOnInit(): void {
        this.productionReportService.getOrgTree().subscribe((data:any)=>{
            this.organizations=this.productionReportService.formation(data)
            this.userDataLoad()
         })

        
      
        
    }

    userDataLoad(){
        this.user.editing = false;
        this.route.paramMap.subscribe((params: ParamMap) => {
            if (params.get('id'))
                this.service.getOne(params.get('id')).subscribe((u: User) => {
                    this.user = u;
                    this.user.password = null;
                    this.onModuleSelect(u.moduleIds.join(','));
                    this.preSelRoles = u.rolesIds;
                    this.user.editing = true;
                    this.selectedorgaization=this.productionReportService.searchTree(this.organizations[0],this.user.orgId)
                });
        });
    }

   
}
