import { TestBed } from '@angular/core/testing';

import { UserOwnServiceService } from './user-own-service.service';

describe('UserOwnServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UserOwnServiceService = TestBed.get(UserOwnServiceService);
    expect(service).toBeTruthy();
  });
});
