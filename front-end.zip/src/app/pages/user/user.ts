
export class User {
    fullName: string;
    govtId: number;
    userName: string;
    password: string;
    mobile: string;
    email: boolean;
    moduleIds: number[];
    rolesIds: any[];
    roles: string;
    editing: boolean;
    orgId: number;

    constructor() { }
}
