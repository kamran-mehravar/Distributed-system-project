import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment as env } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserOwnServiceService {

  apiURL: string;

  constructor(private http: HttpClient) { 
    this.apiURL = env.apiHost + env.apiPrefix;
  }
  deleteUser(id){ 
     return this.http.get(this.apiURL + `/users/${id}`);
  }
}
