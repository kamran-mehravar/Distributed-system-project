import { Component } from '@angular/core';
import { Menu } from '../menu';
import { FormSubmitEvent } from '../../../@common/form-submit.event';
import { MenuService } from '../menu.service';
import { ToastService } from '../../../@core/service/toast.service';
import { ModuleService } from '../../module/module.service';
import { Module } from '../../module/module';

@Component({
    selector: 'ngx-menu-create',
    styleUrls: ['./create.component.scss'],
    templateUrl: './create.component.html',
})
export class MenuCreateComponent extends FormSubmitEvent {

    menu: Menu;
    menus: any;
    modules: any;

    constructor(public service: MenuService, public toaster: ToastService, private moduleService: ModuleService) {
        super(service, toaster);
        this._reset();
    }
    loadModules() {
        this.moduleService.getActive().subscribe((res: Module[]) => {
            res.map(m => this.modules.push({ id: m.id, name: m.name }));
        });
    }
    onModuleChange(moduleId) {
        this.menus = [];
        this.loadMenuList(moduleId);
    }
    loadMenuList(moduleId: number) {
        this.service.getListByModuleId(moduleId).subscribe((res: Menu[]) => {
            res.map(m => { this.menus.push({ id: m.id, title: m.title }); });
        });
    }
    onSubmit() {
        super.submit(this.menu);
    }
    _reset(): void {
        this.menu = new Menu();
        this.menu.active = true;
        this.menus = [];
        this.modules = [];
        this.loadModules();
    }
}
