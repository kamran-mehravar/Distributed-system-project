
export class Menu {
    id: number;
    title: string;
    icon: string;
    link: string;
    home: boolean;
    sortOrder: number;
    external: boolean;
    active: boolean;
    parentId: number;
    moduleId: number;

    constructor() { }

}
