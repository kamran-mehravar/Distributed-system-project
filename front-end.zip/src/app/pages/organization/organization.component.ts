import { Component } from '@angular/core';

@Component({
  selector: 'ngx-organization',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class OrganizationComponent {
}
