import { NbMenuItem } from '@nebular/theme';

export const MENU_ITEMS: NbMenuItem[] = [
    // {
    //     title: 'Dashboard',
    //     icon: 'ion-home',
    //     link: '/home/dashboard',
    //     home: true,
    // },
    {
        title: 'User Management',
        icon: 'lni-users',
        link: '/pages/dashboard',
    },
    // {
    //     title: 'Integration',
    //     icon: 'lni-cog',
    //     link: '/exam/dashboard',
    // },
    // {
    //     title: 'Maintenance',
    //     icon: 'lni-grow',
    //     link: '/legal/dashboard',
    //     home: true,
    // },
    // {
    //     title: 'Master Data',
    //     icon: 'lni-database',
    //     link: '/master-data/client',
    //     home: true,
    // },
    // {
    //     title: 'Production',
    //     icon: 'lni-brick',
    //     link: '/production/one',
    // },

    // {
    //     title: 'Quality',
    //     icon: 'lni-medall',
    //     link: '/quality/dashboard',

    // }


    // {
    //     title: 'Quality',
    //     icon: 'lni-medall',
    //     children: [
    //         {
    //             title: 'TLS Dashboard',
    //             link: '/o-m/dashboard',
    //         },
    //         {
    //             title: 'Quality Dashboard',
    //             link: '/o-m/quality-dashboard',
    //         },
    //     ],
    // },
];
