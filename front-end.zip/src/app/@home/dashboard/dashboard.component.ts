import { Component, OnDestroy, OnInit } from '@angular/core';
import { NbAuthService, NbAuthJWTToken } from '@nebular/auth';
import { ProfileService, AssignedModule } from '../../@core/service/profile.service';
import { Chart } from 'chart.js';
import { PercentPipe } from '@angular/common';

 // core components
  import {
    chartOptions,
    parseOptions,
    chartExample1,
    chartExample2
  } from "../../@core/service/charts";

import { DashboardService } from './dashboard.service'

@Component({
    selector: 'ngx-home',
    styleUrls: ['./dashboard.component.scss'],
    templateUrl: './dashboard.component.html',
})
export class DashboardComponent implements OnInit, OnDestroy {

    public clicked: boolean = true;
    public clicked1: boolean = false;

    isAdmin: boolean = false;
    adminRole = 'ROLE_ADMIN';

    modules: AssignedModule[];

    constructor(private authService: NbAuthService, private profileService: ProfileService, private dashboardService: DashboardService) {

        this.authService.getToken().subscribe(((token: NbAuthJWTToken) => {
            const roles = token.getPayload().roles;
            if (roles.indexOf(this.adminRole) > -1) {
                this.isAdmin = true;
            }
        }));

        this.customizeTooltip = this.customizeTooltip.bind(this);
    }

    customizeLabel(arg) {
        return{
             html: arg.valueText + " (" + arg.percentText + ")"

        };
    }
    customizeTooltip = (arg) => {
      return {
          html: arg.valueText + " (" + arg.argumentText + ")"
      };

    }
    // customizeTooltip2 = (arg: any) => {
    //     return {
    //         text: arg.valueText + " - " + this.pipe.transform(arg.percent, "1.2-2")
    //     };
    // }


    ngOnInit(): void {

        this.profileService.getModules().subscribe((resp: AssignedModule[]) => {
            this.modules = resp;
        });
        this.profileService.resetActiveModule();
        this.dataLoad()
    }

    dataLoad() {

        this.profileService.getModules().subscribe((resp: AssignedModule[]) => {
            this.modules = resp;
        });
        this.profileService.resetActiveModule();
    }

    onModuleChange(module: AssignedModule) {
        this.profileService.setActiveModule(module);
    }
    ngOnDestroy() {

    }
}
