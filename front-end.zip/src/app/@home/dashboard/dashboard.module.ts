import { NgModule } from '@angular/core';

import { ThemeModule } from '../../@theme/theme.module';
import { DashboardComponent } from './dashboard.component';
import { TranslateModule } from '@ngx-translate/core';
import { DxCircularGaugeModule, DxChartModule, DxPieChartModule } from 'devextreme-angular'


@NgModule({
    imports: [
        ThemeModule,
        TranslateModule,
        DxCircularGaugeModule,
        DxChartModule,
        DxPieChartModule
    ],
    declarations: [
        DashboardComponent,
    ],
})
export class DashboardModule { }
