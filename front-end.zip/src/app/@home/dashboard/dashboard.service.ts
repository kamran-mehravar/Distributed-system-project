import { Injectable} from '@angular/core';
import { NbAuthService, NbAuthJWTToken } from '@nebular/auth/services';
import { HttpClient } from '@angular/common/http';

import { environment as env } from '../../../environments/environment'



@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  user = {};
  apiURL: string;

  constructor(private http: HttpClient, private authService: NbAuthService
    ) {
    this.apiURL = env.apiHost + env.apiPrefix + '/v1';
    
  }
   
  getCurrentDateTime():string{
    var today = new Date();
    var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date+'T'+time;
    return dateTime;
  }

  getCurrentFromDate():string{
    var today = new Date();
    let currentYear=today.getFullYear();
    let currentMonth=(today.getMonth()+1);

    var date = currentYear+'-'+currentMonth+'-'+'1';
    var currentFromdate=date+'T'+"00:00:00";
    return currentFromdate
  }

  thisMonthProgress(){
    let startDate=this.getCurrentFromDate()
    let endDate=this.getCurrentDateTime()
    return this.http.get(this.apiURL + '/home/'+  `thismonthprogress?dataSource=1&startDate=${startDate}&endDate=${endDate}`);
  }

  thisMonthProductionBuyer(){
    //string
    let startDate=this.getCurrentFromDate()
    let endDate=this.getCurrentDateTime()
    return this.http.get(this.apiURL + '/home/'+  `thismonthproductionbuyer?dataSource=1&startDate=${startDate}&endDate=${endDate}`);
  }

  thisYearProductionBuyer(){
    //string
    return this.http.get(this.apiURL + '/home/'+  `productionBuyer?dataSource=1`);
  }


  thisYearProductionBar(){
    //string
    return this.http.get(this.apiURL + '/home/'+  `productionBar?dataSource=1`);
  }


  thisMonthDhu(){
    //string
    let startDate=this.getCurrentFromDate()
    let endDate=this.getCurrentDateTime()
    return this.http.get(this.apiURL + '/home/'+  `thismonthdhu?dataSource=1&startDate=${startDate}&endDate=${endDate}`);
    
  }



  thisMonthProduction(){
    //string
    let startDate=this.getCurrentFromDate()
    let endDate=this.getCurrentDateTime()
    return this.http.get(this.apiURL + '/home/'+  `thismonthproduction?dataSource=1&startDate=${startDate}&endDate=${endDate}`);
    
  }


  thisYearProduction(){
    //string
    return this.http.get(this.apiURL + '/home/'+  `organization?dataSource=1`);
  }

  thisMonthEfficiency(){
    //string
     let startDate=this.getCurrentFromDate()
     let endDate=this.getCurrentDateTime()
     
     return this.http.get(this.apiURL + '/home/'+  `thismonthefficiency?dataSource=1&startDate=${startDate}&endDate=${endDate}`);
  }


}
