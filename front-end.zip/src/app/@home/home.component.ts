import { Component } from '@angular/core';
import { MENU_ITEMS } from './home-menu';
import {NbMenuItem, NbMenuService} from '@nebular/theme';
import {AssignedModule, ProfileService} from "../@core/service/profile.service";

@Component({
  selector: 'ngx-home-layout',
  template: `
    <ngx-sample-layout>
      <nb-menu [items]="menu"></nb-menu>
      <router-outlet></router-outlet>
    </ngx-sample-layout>
  `,
})
export class HomeComponent {

  menu : NbMenuItem[] = [];
  staticMenu : NbMenuItem[] = MENU_ITEMS;
  modules: AssignedModule[];

  constructor(private profileService: ProfileService, private menuService: NbMenuService) {

    this.profileService.getModules().subscribe((resp: AssignedModule[]) => {
      this.modules = resp;

      this.modules.forEach(module => {
        //{id: 2, name: "Integration", contextPath: "/exam/dashboard", image: "lni-cog"}
        this.menu.push({
          target: module.id+"",
          title: module.name,
          icon: module.image,
          link: module.contextPath,
        })
      });

      //this.profileService.resetActiveModule();
      this.menuService.onItemClick().subscribe((event) => {
        if(event.item.target) {
          var assignedModule:AssignedModule  = {
            id: Number(event.item.target),
            name:event.item.title,
            image:event.item.icon,
            contextPath: event.item.link
          };
          console.log(assignedModule);
          this.profileService.setActiveModule(assignedModule);
        }
      });
    });
  }
}
