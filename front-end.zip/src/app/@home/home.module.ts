import { NgModule } from '@angular/core';

import { HomeComponent } from './home.component';
import { DashboardModule } from './dashboard/dashboard.module';
import { HomeRoutingModule } from './home-routing.module';
import { ThemeModule } from '../@theme/theme.module';
import { TranslateModule } from '@ngx-translate/core';
import { ProfileModule } from './profile/profile.module';
@NgModule({
    imports: [
        HomeRoutingModule,
        ThemeModule,
        DashboardModule,
        ProfileModule,
        TranslateModule,
    ],
    declarations: [
        HomeComponent,
    ],
})
export class HomeModule {
}
