export class ChangePassword {
    oldPassword: string;
    password: string;
    verifyPassword: string;
}
