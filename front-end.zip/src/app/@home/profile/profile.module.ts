import { NgModule } from '@angular/core';

import { ThemeModule } from '../../@theme/theme.module';
import { TranslateModule } from '@ngx-translate/core';
import { ProfileComponent } from './profile.component';

@NgModule({
    imports: [
        ThemeModule,
        TranslateModule,
    ],
    declarations: [
        ProfileComponent,
    ],
})
export class ProfileModule { }
