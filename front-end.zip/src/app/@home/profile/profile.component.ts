import { Component, OnInit } from '@angular/core';
import { ChangePassword } from './profile';
import { ProfileService } from '../../@core/service/profile.service';

@Component({
    selector: 'ngx-profile',
    templateUrl: './profile.component.html',
    styleUrls: ['./profile.component.scss'],
})
export class ProfileComponent implements OnInit {

    redirectDelay: number = 0;
    showMessages: any = {};
    strategy: string = '';

    submitted = false;
    errors: string[] = [];
    messages: string[] = [];
    cp: ChangePassword;

    constructor(private profileService: ProfileService) { }

    ngOnInit() {
        this.cp = new ChangePassword();
    }

    resetPass() {
        this.errors = this.messages = [];
        this.submitted = true;
        this.profileService.changePassword(this.cp).subscribe(resp => {
            this.submitted = false;
        }, error => {
            this.submitted = false;
        });
    }

}
