import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment';
import { environment as env } from '../../../environments/environment';

@Pipe({
    name: 'formatDate',
})
export class DatePipe implements PipeTransform {

    MONTH = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

    transform(date: any, args?: any): any {
        const arr = date.split('/');
        // tslint:disable-next-line: radix
        const temp = arr[0] + '-' + this.MONTH[parseInt(arr[1]) - 1] + '-' + arr[2];
        return new Date(temp);
    }

    toStr(date: any, args?: any): any {
         const d = new Date(date);
        return moment(d).format(env.dateFormat);
    }
}
