import { Component, Input } from '@angular/core';
import { NbPopoverDirective, NbLayoutDirection, NbLayoutDirectionService } from '@nebular/theme';
import { TranslateService } from '@ngx-translate/core';

@Component({
    selector: 'ngx-lang-switcher-list',
    templateUrl: './language-switcher-list.component.html',
    styleUrls: ['./language-switcher-list.component.scss'],
})

export class LangSwitcherListComponent {

    @Input() popover: NbPopoverDirective;
    directions = NbLayoutDirection;
    currentDirection: NbLayoutDirection;

    languages = [];

    constructor(private translate: TranslateService, private directionService: NbLayoutDirectionService) {

        this.translate.get(['English', 'Bangla', 'Turkish']).subscribe(translations => {
            this.languages = [
                {
                    title: translations.English,
                    imgUrl: 'assets/flags/en.png',
                    key: 'en',
                },
                {
                    title: translations.Bangla,
                    imgUrl: 'assets/flags/bn.png',
                    key: 'bn',
                },
                {
                    title: translations.Turkish,
                    imgUrl: 'assets/flags/turkish.png',
                    key: 'tk',
                },
            ];
        });

        this.currentDirection = this.directionService.getDirection();
        this.directionService.onDirectionChange()
            .subscribe(newDirection => this.currentDirection = newDirection);
    }

    onToggleLang(langKey: string) {
        if (langKey === 'bn') {
            this.translate.use('bn');
        } else if (langKey === 'tk') {
            this.translate.use('tk');
        } else {
            this.translate.use('en');
        }
        this.popover.hide();
    }
}
