import { TemplateRef, Injectable } from '@angular/core';
import { NbDialogService } from '@nebular/theme';
import { InfoDialogComponent } from './info-dialog/info-dialog.component';

@Injectable()
export class DialogService {

    names: string[] = [];

    constructor(private dialogService: NbDialogService) { }

    alert(message: string) {
        this.open('Alert', message);
    }

    open(title: string, message: string) {
        this.dialogService.open(InfoDialogComponent, {
            context: {
                title: title,
                message: message,
            },
            closeOnEsc: true,
            hasBackdrop: true,
        });
    }

}
