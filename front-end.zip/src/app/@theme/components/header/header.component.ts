import { Component, Input, OnInit } from '@angular/core';

import { NbMenuService, NbSidebarService } from '@nebular/theme';
import { AnalyticsService } from '../../../@core/utils';
import { LayoutService } from '../../../@core/utils';
import { NbAuthService, NbAuthJWTToken } from '@nebular/auth';
import { PubSubService } from '../../../@core/service';

@Component({
    selector: 'ngx-header',
    styleUrls: ['./header.component.scss'],
    templateUrl: './header.component.html',
})
export class HeaderComponent implements OnInit {

    @Input() position = 'normal';

    user: any = {};

    activeModuleName: String = 'Second-hand Car Advertisement application ';

    userMenu = [{ title: 'Change Password', link: 'home/profile' }, { title: 'Log out', link: 'auth/logout' }];

    constructor(private sidebarService: NbSidebarService,
        private menuService: NbMenuService,
        private analyticsService: AnalyticsService,
        private layoutService: LayoutService,
        private pubSubService: PubSubService,
        private authService: NbAuthService) {
        this.authService.onTokenChange()
            .subscribe((token: NbAuthJWTToken) => {
                if (token.isValid()) {
                    this.user = token.getPayload();
                }
            });
    }

    ngOnInit() {
         this.pubSubService.Stream.subscribe(mod => {
            this.activeModuleName = mod.name;
        });
    }

    toggleSidebar(): boolean {
        this.sidebarService.toggle(true, 'menu-sidebar');
        this.layoutService.changeLayoutSize();
        return false;
    }

    goToHome() {
        this.menuService.navigateHome();
    }

    startSearch() {
        this.analyticsService.trackEvent('startSearch');
    }

    // ngx typeahead
    public url = 'http://suggestqueries.google.com/complete/search';
    public params = {
        hl: 'en',
        ds: 'yt',
        xhr: 't',
        client: 'youtube',
    };
    public query = '';
    isShow = false
    noValue = " "

    handleResultSelected(result) {
        this.query = result;
    }

    items = [
        { title: 'Module 1' },
        { title: 'Module 2' },
        { title: 'Module 3' },
    ];

    slides = [
        {link: "#", title: "Module 01", icon: "lni-cog" },
        {link: "#", title: "Module 02", icon: "lni lni-cloudnetwork" },
        {link: "#", title: "Module 03", icon: "lni lni-coin" },
        {link: "#", title: "Module 04", icon: "lni lni-comment" },
        {link: "#", title: "Module 05", icon: "lni lni-construction-hammer" },
        {link: "#", title: "Module 06", icon: "lni lni-crown" }
    ];
    slideConfig = {
        "slidesToShow": 3,
        "slidesToScroll": 1,
        "arrows" : true,
        "infinite": false,
        "nextArrow":"<div class='nav-btn next-slide'><i class='lni-chevron-right'></i></div>",
        "prevArrow":"<div class='nav-btn prev-slide'><i class='lni-chevron-left'></i></div>",
        "responsive": [
            {
            "breakpoint": "null",
            "settings": {
                "arrows": false,
                "centerMode": true,
                "centerPadding": '40px',
                "slidesToShow": 2
            }
            },
            {
            "breakpoint": 480,
            "settings": {
                "arrows": false,
                "centerMode": true,
                "centerPadding": '40px',
                "slidesToShow": 1
            }
            }
        ]
    };

    breakpoint(e) {
        console.log(e);
  }

}
