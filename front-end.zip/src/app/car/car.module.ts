import { NgModule } from '@angular/core';

import { CarComponent } from './car.component';
import { CarRoutingModule } from './car-routing.module';
import { ThemeModule } from '../@theme/theme.module';
import { TranslateModule } from '@ngx-translate/core';
import { DualListBoxModule } from 'ng2-dual-selector';
import { TagInputModule } from 'ngx-chips';
import { OrganizationModule as orgModule } from '../pages/organization/organization.module';
// ag-grid
import { AgGridModule } from 'ag-grid-angular';
// DevExtreme
import { DxDataGridModule, DxListModule, DxDropDownBoxModule, DxTagBoxModule, DxChartModule } from 'devextreme-angular';
import { DxSelectBoxModule, DxTreeListModule, DxButtonModule } from 'devextreme-angular';
import { DxDrawerComponent, DxDrawerModule, DxToolbarModule } from 'devextreme-angular';
import { DxDateBoxModule, DxTextBoxModule, DxTextAreaModule, DxSwitchModule } from 'devextreme-angular';
import { DxSliderModule, DxValidatorModule, DxValidationSummaryModule, DxNumberBoxModule} from 'devextreme-angular';

import { Ng2SmartTableModule } from 'ng2-smart-table';
import { SimplebarAngularModule } from 'simplebar-angular';
import {DashboardModule} from './dashboard/dashboard.module';
import {ListComponent} from './list/list.component';

const ADVERTISEMENT_COMPONENTS = [
    CarComponent, ListComponent
];

@NgModule({
  declarations: [...ADVERTISEMENT_COMPONENTS],
  imports: [
    CarRoutingModule,
    DashboardModule,
    ThemeModule,
    Ng2SmartTableModule,
    TranslateModule,
    DualListBoxModule,
    AgGridModule,
    TagInputModule,
    DxDataGridModule, DxListModule, DxDropDownBoxModule, DxTagBoxModule, DxChartModule, DxSelectBoxModule,
    orgModule, DxTreeListModule,
    DxSwitchModule, DxSliderModule, DxValidatorModule, DxValidationSummaryModule, DxNumberBoxModule,
    DxButtonModule, DxDrawerModule, DxToolbarModule, DxDateBoxModule, DxTextBoxModule,
    DxTextAreaModule, SimplebarAngularModule,
  ],
})
export class CarModule {}
