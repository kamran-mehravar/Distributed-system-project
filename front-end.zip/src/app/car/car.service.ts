import { Injectable } from '@angular/core';
import {BaseService} from '../@common';
import {HttpClient} from '@angular/common/http';
import { environment as env } from '../../environments/environment';


@Injectable({
  providedIn: 'root',
})
export class CarService {

    apiURL: string;
    constructor(private http: HttpClient) {
        this.apiURL = env.apiHost + env.apiPrefix + '/v1';
    }
    getAll() {
        return this.http.get(this.apiURL + '/cars');
    }
    getCount() {
        return this.http.get(this.apiURL + '/cars/count');
    }
}
