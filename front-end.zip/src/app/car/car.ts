export class Car {
    id: number;
    region: string;
    price: number;
    year: string;
    manufacturer: string;
    model: string;
    fuel: string;
    constructor() {

    }
  }
