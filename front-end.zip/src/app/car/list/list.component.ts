import { Component } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';
import { IDModel } from '../../@core/models';
import { ToastService } from '../../@core/service/toast.service';
import {Car} from '../car';
import {CarService} from '../car.service';
import {OrderService} from '../../order/order.service';
import {Order} from '../../order/order';

@Component({
    selector: 'ngx-location-list',
    templateUrl: './list.component.html',
    styles: [`
    nb-card {
      transform: translate3d(0, 0, 0);
    }
  `],
})
export class ListComponent   {


    settings = {
        mode: 'inline',
        pager: {
            perPage: 10,
        },
        actions: {
            add: false,
            edit: false,
            delete: false,
        },
        add: {
            addButtonContent: '<i class="nb-plus"></i>',
            createButtonContent: '<i class="nb-checkmark"></i>',
            cancelButtonContent: '<i class="nb-close"></i>',
            confirmCreate: true,
        },
        edit: {
            editButtonContent: '<i class="nb-edit"></i>',
            saveButtonContent: '<i class="nb-checkmark"></i>',
            cancelButtonContent: '<i class="nb-close"></i>',
            confirmSave: true,
        },
        delete: {
            deleteButtonContent: '<i class="ion-document" title="Place Order"></i>',
            confirmDelete: true,
        },
        columns: {
            id: IDModel,
            region: {
                title: 'Region',
                type: 'string',
            },
            price: {
                title: 'Price',
                type: 'string',
            },
          year: {
                title: 'Year',
                type: 'string',
            },
          manufacturer: {
                title: 'Manufacturer',
                type: 'string',
            },
          model: {
                title: 'Model',
                type: 'string',
            },
          fuel: {
                title: 'Fuel',
                type: 'string',
            },
        },
    };

  source: LocalDataSource = new LocalDataSource();

  constructor(public service: CarService, public orderService: OrderService, public toaster: ToastService) {
    this.load();
  }

  load(): void {
    this.service.getAll().subscribe((res: any) => {
      this.source.load(res.content as Car[]);
    });
  }

  reloadGrid(): void {
    this.load();
  }

  onCreate(event): void {
    /*this.service.save(event.newData).subscribe(response => {
      if (response.status) {
        this.toaster.created();
        event.confirm.resolve();
        this.reloadGrid();
      } else {
        this.toaster.notCreated();
      }
    });*/
  }

  onEdit(event): void {
    /*this.service.update(event.newData).subscribe(response => {
      if (response.status) {
        this.toaster.updated();
        event.confirm.resolve();
        this.reloadGrid();
      } else {
        this.toaster.notUpdated();
      }
    });*/
  }

  onPlaceOrderConfirm(event: any) {

  }
}
