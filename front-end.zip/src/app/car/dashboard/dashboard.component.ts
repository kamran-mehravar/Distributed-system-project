import {Component,  OnInit} from '@angular/core';
import {CarService} from '../car.service';

@Component({
    selector: 'ngx-dashboard',
    styleUrls: ['./dashboard.component.scss'],
    templateUrl: './dashboard.component.html',
})
export class DashboardComponent implements OnInit {
  carCount = '';
  constructor(private carService: CarService) {
  }

    ngOnInit() {
      this.carService.getCount().subscribe((res: any) => {
        if (res.statusCode === 200) {
          this.carCount = 'Total Car: ' + res.content;
        }
      });
    }
}
