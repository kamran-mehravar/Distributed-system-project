import { ModuleWithProviders, NgModule, Optional, SkipSelf } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
    NbAuthModule, NbPasswordAuthStrategy, NbAuthJWTToken,
} from '@nebular/auth';
import { NbSecurityModule, NbRoleProvider } from '@nebular/security';
import { of as observableOf } from 'rxjs';


import { throwIfAlreadyLoaded } from './module-import-guard';
import {
    AnalyticsService,
    LayoutService,
    PlayerService,
    StateService,
} from './utils';
import { environment } from '../../environments/environment';
import {  } from './service/profile.service';
import { ProfileData, ProfileService, ToastService, DialogService } from './service';
import { NbCustomRoleProvider } from '../@auth/role.provider';

const DATA_SERVICES = [
    { provide: ProfileData, useClass: ProfileService },
    ToastService,
    DialogService,
];

// https://github.com/akveo/nebular/blob/2.0.0-rc.10/src/playground/auth/auth.module.ts
export class NbSimpleRoleProvider extends NbRoleProvider {
    getRole() {
        // here you could provide any role based on any auth flow
        return observableOf('guest');
    }
}

export class JWTToken extends NbAuthJWTToken {
    accessToken: string;
    tokenType: string;
    rememberMe?: boolean;
}

export const NB_CORE_PROVIDERS = [
    ...DATA_SERVICES,
    ...NbAuthModule.forRoot({
        strategies: [
            NbPasswordAuthStrategy.setup({
                name: 'email',
                baseEndpoint: environment.apiHost + '/auth',
                login: {
                    endpoint: '/login',
                },
                logout: {
                    endpoint: '/logout',
                },
                token: {
                    class: JWTToken,
                    key: 'accessToken',
                },
            }),
        ],
        forms: {},

    }).providers,

    NbSecurityModule.forRoot({
        accessControl: {
            guest: {
                view: '*',
            },
            user: {
                parent: 'guest',
                create: '*',
                edit: '*',
                remove: '*',
            },
        },
    }).providers,

    {
        provide: NbRoleProvider, useClass: NbSimpleRoleProvider,
    },
    AnalyticsService,
    LayoutService,
    PlayerService,
    StateService,
    ProfileService,
];

@NgModule({
    imports: [
        CommonModule,
    ],
    exports: [
        NbAuthModule,
    ],
    declarations: [],
})
export class CoreModule {
    constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
        throwIfAlreadyLoaded(parentModule, 'CoreModule');
    }

    static forRoot(): ModuleWithProviders {
        return <ModuleWithProviders>{
            ngModule: CoreModule,
            providers: [
                ...NB_CORE_PROVIDERS,
            ],
        };
    }
}
