export const FilterModel = {
    type: 'checkbox',
    config: {
        true: 'true',
        false: 'false',

    },
    resetText: 'Clear',
};
