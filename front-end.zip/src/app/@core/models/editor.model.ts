export const EditorModel = {
    type: 'checkbox',
    config: {
        true: true,
        false: false,
    },
};
