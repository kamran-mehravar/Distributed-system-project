export enum CaseFormType {
    HIGHCOURT, ADMIN,
}