export const IDModel = {
    title: 'ID',
    type: 'number',
    editable: false,
    addable: false,
};