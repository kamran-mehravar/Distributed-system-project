export interface Error {
    status: string;
    message: string;
    errors: string[];
}
