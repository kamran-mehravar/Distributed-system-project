import { Injectable } from '@angular/core';
import { NbAuthService, NbAuthJWTToken } from '@nebular/auth/services';
import { HttpClient } from '@angular/common/http';

import { environment as env } from '../../../environments/environment';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { PubSubService } from './pub-sub.service';

export interface AssignedModule {
    id: number;
    name: string;
    contextPath: string;
    image: string;
}

@Injectable()
export class ProfileService {

    user = {};
    apiURL: string;

    constructor(private http: HttpClient, private authService: NbAuthService,
        private pubSubService: PubSubService) {
        this.apiURL = env.apiHost + env.apiPrefix + '/users';
        this.authService.onTokenChange()
            .subscribe((token: NbAuthJWTToken) => {
                if (token.isValid()) {
                    this.user = token.getPayload();
                }
            });

    }

    getModules(): Observable<any> {
        return this.http.get(this.apiURL + '/modules');
    }

    setActiveModule(mod: AssignedModule) {
        localStorage.setItem('activeModule', JSON.stringify(mod));
        this.pubSubService.Stream.emit(mod);
    }

    resetActiveModule() {
        localStorage.removeItem('activeModule');
    }

    getActiveModule(): AssignedModule {
        return JSON.parse(localStorage.getItem('activeModule'));
    }

    changePassword(data: any): Observable<any> {
        return this.http.post(this.apiURL + '/change-password', data);
    }

    hasModuleAccess(contextPath: string): Observable<boolean> {
        return this.getModules().pipe(map((res: AssignedModule[]) => {
            let matched: boolean = false;
            res.forEach(e => {
                if (e.contextPath === contextPath) {
                    matched = true;
                }
            });
            return matched;
        }));
    }
}
