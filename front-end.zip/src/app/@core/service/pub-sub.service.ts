import { ModuleChangeEventEmitter } from './module-event-emitter';
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class PubSubService {

    Stream: ModuleChangeEventEmitter;

    constructor() {
        this.Stream = new ModuleChangeEventEmitter();
    }
}
