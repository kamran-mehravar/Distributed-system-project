import { Subject } from 'rxjs/Subject';
import { AssignedModule } from '.';

export class ModuleChangeEventEmitter extends Subject<AssignedModule> {

    constructor() {
        super();
    }

    emit(value: any) { super.next(value); }
}
