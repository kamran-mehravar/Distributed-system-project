import { NbToastrService } from '@nebular/theme';
import { Injectable } from '@angular/core';

export interface Toast {
    title: string;
    message: string;
}

@Injectable()
export class ToastService {

    constructor(private toastService: NbToastrService) {
    }

    info(data: Toast): void {
        this.toastService.info(data.message, data.title);
    }

    error(data: Toast): void {
        this.toastService.danger(data.message, data.title);
    }

    danger(data: Toast): void {
        this.toastService.danger(data.message, data.title);
    }

    success(data: Toast): void {
        this.toastService.success(data.message, data.title);
    }

    warn(data: Toast): void {
        this.toastService.warning(data.message, data.title);
    }

    created(): void {
        this.success({ message: 'Record saved successfully!', title: 'Success' });
    }

    notCreated(): void {
        this.error({ message: 'Error while saving record!', title: 'Error' });
    }

    updated(): void {
        this.success({ message: 'Record updated successfully!', title: 'Success' });
    }

    notUpdated(): void {
        this.error({ message: 'Error while updating record!', title: 'Error' });
    }

    deleted(): void {
        this.success({ message: 'Record deleted successfully!', title: 'Success' });
    }

    notDeleted(): void {
        this.error({ message: 'Error while deleting record!', title: 'Error' });
    }

    cantDelete(): void {
        this.error({ message: 'Record is not Deletable !!', title: 'Error' });
    }

    duplicateRecord(): void {
        this.error({ message: 'Duplicate Record !!', title: 'Error' });
    }
}
