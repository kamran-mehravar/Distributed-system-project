import { BaseEvents } from './base.events';
import { BaseService } from './base.service';
import { ToastService } from '../@core/service/toast.service';

export abstract class InlineGridEvents extends BaseEvents {

    constructor(public service: BaseService, public toaster: ToastService) {
        super(service, toaster);
    }

    abstract reloadGrid();

    onCreate(event): void {
        this.service.save(event.newData).subscribe(response => {
            if (response.status) {
                this.toaster.created();
                event.confirm.resolve();
                this.reloadGrid();
            } else {
                this.toaster.notCreated();
            }
        });
    }

    onEdit(event): void {
        this.service.update(event.newData).subscribe(response => {
            if (response.status) {
                this.toaster.updated();
                event.confirm.resolve();
                this.reloadGrid();
            } else {
                this.toaster.notUpdated();
            }
        });
    }
}
