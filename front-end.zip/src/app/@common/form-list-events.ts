import { BaseEvents } from './base.events';
import { BaseService } from './base.service';
import { ToastService } from '../@core/service/toast.service';
import { DatePipe } from '../@theme/pipes';
import * as moment from 'moment';

export abstract class FormAndListEvents extends BaseEvents {
  constructor(public service: BaseService, public toaster: ToastService) {
    super(service, toaster);
  }

  abstract reloadGrid();
  abstract _reset();
  datePipe: DatePipe = new DatePipe();

  submit(data: any) {
    this.service.save(data).subscribe(response => {
      if (response.status) {
        if (response.status === 204) {
          this.toaster.duplicateRecord();
        } else {
          this.toaster.created();
          this._reset();
          this.reloadGrid();
        }
      } else {
        this.toaster.notCreated();
      }
    });
  }

  saveOrUpdate(data: any, urlParam: any) {
    this.service.saveOrUpdate(data, urlParam).subscribe(response => {
      if (response.status) {
        if (response.status === 204) {
          this.toaster.duplicateRecord();
        } else {
          this.toaster.created();
          this._reset();
          this.reloadGrid();
        }
      } else {
        this.toaster.notCreated();
      }
    });
  }

  onCreate(event): void {
    this.service.save(event.newData).subscribe(response => {
      if (response.status) {
        this.toaster.created();
        event.confirm.resolve();
        this.reloadGrid();
      } else {
        this.toaster.notCreated();
      }
    });
  }

  onEdit(event): void {
    this.service.update(event.newData).subscribe(response => {
      if (response.status) {
        this.toaster.updated();
        event.confirm.resolve();
        this.reloadGrid();
      } else {
        this.toaster.notUpdated();
      }
    });
  }

  compareFn(a, b) {
    return a && b && a.id === b.id;
  }

  setDate(data, dtp) {
    // @ts-ignore
    $(dtp).trigger('setDate', null);
    if (data) {
      const arr = data.split('/');
      const data2 = arr[2] + '-' + arr[1] + '-' + arr[0];
      // @ts-ignore
      $(dtp).val(data2).trigger('change');
    }
  }
  getDateForServer(date: string) {
    let retVal = '';
    if (date.indexOf('/') > 0) {
      retVal = date;
    } else {
      const arr = date.split('-');
      retVal = arr.reverse().join('/');
    }
    return retVal;
  }
  toStr(d: any) {
    return this.datePipe.toStr(d);
  }
  toDate(d: any) {
    return d ? this.datePipe.transform(d) : d;
  }

  ngOnInit() {
    // let el: any;
    // $(document).ready(function () {
    //   $('.custom-date').on('change', function () {
    //     el = this;
    //     this.setAttribute(
    //       'data-date',
    //       moment(el.value, 'YYYY-MM-DD')
    //         .format(this.getAttribute('data-date-format')),
    //     );
    //   });
    // });
  }
}
