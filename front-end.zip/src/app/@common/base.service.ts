import { Observable } from 'rxjs';
import { HttpResponse, HttpClient } from '@angular/common/http';

import { environment as env } from '../../environments/environment';

export abstract class BaseService {

    specificPlants: any = {
        name: '',
        address: '',
        code: '',
        head: '',
        type: '',
        parentId: '',
      };

      organizations: any;


    constructor(public apiURL: string, public http: HttpClient) {
        this.apiURL = env.apiHost + env.apiPrefix + apiURL;

    }

    getOne(id: string) {
        return this.http.get(this.apiURL + '/' + id);
    }
    getAll() {
        // return this.http.get(env.apiHost + env.apiPrefix + "/loggedUserOrg");\
        return this.http.get(this.apiURL + ':all');

    }
    childOrganization(id: number, recordType: any) {
        return this.http.get(this.apiURL + '/childOrganization/' + id + '?recordType=' + recordType);
    }
    childOrganization1(id: number, recordType: any) {
        return this.http.get(this.apiURL + '/childOrganization1/' + id + '?recordType=' + recordType);
    }
    getActive() {
        return this.http.get(this.apiURL);
    }
    getTree() {
        // return this.http.get(this.apiURL + ':tree');
        return this.http.get(env.apiHost + env.apiPrefix + '/org:loggedUserOrgtree');
    }
    save(data: any): Observable<HttpResponse<Object>> {
        return this.http.post(this.apiURL, data, { observe: 'response' });
    }
    update(data: any): Observable<HttpResponse<Object>> {
        return this.http.put(this.apiURL, data, { observe: 'response' });
    }
    saveOrUpdate(data: any, urlParam: any): Observable<HttpResponse<Object>> {
        return this.http.post(this.apiURL + '/' + urlParam, data, { observe: 'response' });
    }
    delete(id: number): Observable<HttpResponse<Object>> {
        return this.http.delete(this.apiURL + '/' + id, { observe: 'response' });
    }
    upload(url: string, file: File) {
        const formData: FormData = new FormData();
        if (file) {
            formData.append('files', file, file.name);
        }
        return this.http.post(url, formData);
    }

    insertOrganization(item) {
        return this.http.post(this.apiURL, item);
    }





    getOrganizationByParentId(id: any) {
        return this.http.get(this.apiURL + `/allOrg?parentId=${id}`);
    }

    getAllOrganization() {
        return this.http.get(this.apiURL + ':all');
    }

    updateOrganization(item) {
        return this.http.put(this.apiURL, item);
    }

    deleteOrganization(id) {
        return this.http.delete(this.apiURL + `/${id}`);
    }
}
