import { VERSION } from '@angular/core';
import { HttpClient, HttpResponse, HttpEventType } from '@angular/common/http';

import { environment as env } from '../../environments/environment';
export abstract class FileUploadComponent {

    percentDone: number;
    uploadSuccess: boolean;

    constructor(public apiURL: string, public http: HttpClient) {
        this.apiURL = env.apiHost + env.apiPrefix + apiURL;
    }

    version = VERSION;

    upload(files: File[]) {
        // pick from one of the 4 styles of file uploads below
        this.uploadAndProgress(files);
    }

    basicUpload(files: File[]) {
        const formData = new FormData();
        Array.from(files).forEach(f => formData.append('file', f));
        this.http.post(this.apiURL, formData)
            .subscribe(event => {
            });
    }

    basicUploadSingle(file: File) {
        this.http.post('https://file.io', file)
            .subscribe(event => {
            });
    }

    uploadAndProgress(files: File[]) {
        const formData = new FormData();
        Array.from(files).forEach(f => formData.append('file', f));

        this.http.post('https://file.io', formData, { reportProgress: true, observe: 'events' })
            .subscribe(event => {
                if (event.type === HttpEventType.UploadProgress) {
                    this.percentDone = Math.round(100 * event.loaded / event.total);
                } else if (event instanceof HttpResponse) {
                    this.uploadSuccess = true;
                }
            });
    }

    uploadAndProgressSingle(file: File) {
        this.http.post('https://file.io', file, { reportProgress: true, observe: 'events' })
            .subscribe(event => {
                if (event.type === HttpEventType.UploadProgress) {
                    this.percentDone = Math.round(100 * event.loaded / event.total);
                } else if (event instanceof HttpResponse) {
                    this.uploadSuccess = true;
                }
            });
    }
}
