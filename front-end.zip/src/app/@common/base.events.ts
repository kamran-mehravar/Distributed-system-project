import { BaseService } from './base.service';
import { ToastService } from '../@core/service/toast.service';

export abstract class BaseEvents {

    constructor(public service: BaseService, public toaster: ToastService) {
    }

    onDeleteConfirm(event): void {
        if (window.confirm('Are you sure you want to delete?')) {
            this.service.delete(event.data.id).subscribe(response => {
                if (response.body) {
                    this.toaster.cantDelete();
                } else {
                    if (response.status) {
                        event.confirm.resolve();
                    } else {
                        event.confirm.reject();
                    }
                }
            });
        } else {
            event.confirm.reject();
        }
    }
}
