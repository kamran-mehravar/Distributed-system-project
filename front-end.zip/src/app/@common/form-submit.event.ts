import { ToastService } from '../@core/service/toast.service';
import { BaseService } from './base.service';


export abstract class FormSubmitEvent {

    constructor(public service: BaseService, public toaster: ToastService) {
    }

    abstract _reset();

    submit(data: any) {
        this.service.save(data).subscribe(response => {
            if (response.status) {
                this.toaster.created();
                this._reset();
            } else {
                this.toaster.notCreated();
            }
        });

    }
}
