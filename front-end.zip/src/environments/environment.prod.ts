/**
 * @license
 * Copyright Akveo. All Rights Reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 */
export const environment = {
  production: true,
  apiHost: 'http://10.2.1.29:8087/backend',
  apiPrefix: '/api',
  dateFormat: 'DD/MM/YYYY',
};
