/**
 * @license
 * Copyright Akveo. All Rights Reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 */
// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.
// apiHost: 'http://123.49.62.227:9007/mopa',

export const environment = {
  production: false,
  // apiHost: 'http://3.0.176.40:8080/app',
 //apiHost: 'http://localhost:8080',
 apiHost: 'http://10.2.1.29:8087/backend',

 apiPrefix: '/api',
 dateFormat: 'DD/MM/YYYY',

};
